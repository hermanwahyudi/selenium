package runTest;

import java.io.IOException;

import report.ConvertJPG;
import report.CreateGraphicReport;
import report.SendEmailReport;

public class ExecuteMain {
	
	public static void main (String[]args) throws Exception, IOException {	
		System.out.println("Dexter Android Laboratory!");
			
		CreateGraphicReport._execute();
		ConvertJPG._launch();
		
//		/*
//		 * @param String mailAddress, String sheet 
//		 * 
//		 * */
		SendEmailReport._send(args[0], args[1]);
		
		System.out.println("TOKOPEDIA AUTOMATION TEST SUCCESSFULL");
		System.out.println("EXIT");
		System.out.println("TOKOPEDIA DEXTER VERSION 1.0");	
		
	}

}