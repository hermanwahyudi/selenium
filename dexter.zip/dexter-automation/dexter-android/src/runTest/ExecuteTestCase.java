package runTest;

import io.appium.java_client.android.AndroidDriver;

import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import objects.Scenario;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.ITestResult;
import org.testng.Reporter;
import org.testng.SkipException;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import read.ReadExcelFile;
import read.ReadObject;
import utils.AppiumServer;
import utils.Log;
import utils.Tag;
import action.KeywordAction;


public class ExecuteTestCase {
	String testID;	
	String testName;
	String sheet;
	
	KeywordAction action;
	AppiumServer server = new AppiumServer();
	
	ReadObject object;
	Properties allObjects;

	AndroidDriver<WebElement> driver= null;
	
	// Recieve parameters from jenkins -> ant build.xml -> testng.xml
	// setUpTest going to be run berfore any test run.
	// Setting up browser and sheet name to test.	
	@Parameters({"sheet"})
    @BeforeTest
    public void getParameters(String sheet) {
    	this.sheet = sheet;
    	server.startServer();
	}
	
	@BeforeMethod
	public void createDriver() throws MalformedURLException {
		DesiredCapabilities capabilities = new DesiredCapabilities();
		capabilities.setCapability("device", "Android");
		capabilities.setCapability(CapabilityType.BROWSER_NAME, "");
		capabilities.setCapability("deviceName", "AndroidTestDevice");		
		capabilities.setCapability("appPackage", "com.tokopedia.tkpd");
		capabilities.setCapability("appActivity", ".SplashScreen");
		driver = new AndroidDriver<WebElement>(new URL("http://127.0.0.1:4723/wd/hub"), capabilities);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		
		action = new KeywordAction(this.driver);
    	
		// read object properties file
		object = new ReadObject();
		try {
			allObjects =  object.getObjectRepository();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
	}
	
	@Test(dataProvider="scenario")
	public void testScenario(Object scenario) throws Exception {
		Log.info("======== Running testScenario ========");
		Scenario scene = (Scenario) scenario;

		if (scene.getScenarioDetail() == null) {
			throw new SkipException("[SKIPPING] --- Empty Scenario!!! Skipping ---");
		}		
		
		testID = scene.getScenarioDetail()[Scenario.CELL_TS_ID];
		testName = scene.getScenarioDetail()[Scenario.CELL_TESTCASENAME];
		String tags = scene.getScenarioDetail()[Scenario.CELL_TAGS];
		List<String[]> steps = scene.getSteps();

		Log.info("Scenario: " + testName + " ID: " + testID);

		if (tags != null && tags.toLowerCase().contains(Tag.SKIP)) {
			// skipping test.
			Log.i("--- SKIPPING ---");
			Log.i("--- Test ID: " + testID);
			Log.i("--- Test Name: " + testName);
			Log.i("--- Steps: ");
		
			for (String[] step : steps) {
				Log.i("-------> " + Arrays.toString(step));
			}
			
			Reporter.log(String.format("[SKIPPING] Scenario with testID: %s, testName: %s is skipped due to 'skip' tag.\nTags detail: %s",testID, testName, tags));
			throw new SkipException(String.format("[SKIPPING] --- Skipping scenario: %s ---", testName));
		}
		
		Log.i("Number of steps: " + steps.size());
		
		for (String[] step : steps) {
			String stepTags = step[Scenario.CELL_TAGS];
			if (stepTags != null && stepTags.contains(Tag.SKIP)) {
				step[Scenario.CELL_STATE] = "SKIP";
				Log.i("[LOG] --- SKIPPING STEPS ---");
				Log.i("[LOG] --- Steps: " + Arrays.toString(step) + " ---");
				Log.i("[LOG] --- Continue to next steps ---");

				Reporter.log("[SKIPPING] operation: " + Arrays.toString(step) + " is skipped due to 'skip' tag.");
				continue;
			}
			Thread.sleep(1500);
			action.perform(allObjects, step[Scenario.CELL_TS_ID], step[Scenario.CELL_KEYWORD], step[Scenario.CELL_OBJECT], step[Scenario.CELL_VALUE], step[Scenario.CELL_TAGS]);
			step[Scenario.CELL_STATE] = "PASS";
		}
				
	}
	
	@DataProvider(name="scenario")
	public Object[][] getScenarioDataFromExcel() throws IOException {

		ReadExcelFile file = new ReadExcelFile();
		Sheet excelSheet = file.readExcel(System.getProperty("user.dir") + File.separator, "TestSuites.xlsx" , this.sheet);
		int rowCount = excelSheet.getLastRowNum()-excelSheet.getFirstRowNum();
		Scenario scenario = null;

		List<Scenario[]> provider = new ArrayList<Scenario[]>();
		List<String[]> steps = null;

		for (int i = 0; i < rowCount; i++) {
			//Loop over all the rows
			Row row = excelSheet.getRow(i+1);
			// Check first cell on every row, if first cell is not empty, start new scenario. if empty, continue add steps on current scenario.
			String firstCell = row.getCell(0).toString();
			if (firstCell != null && firstCell.length() > 0) {
				if (scenario == null) {
					scenario = new Scenario();
				} else {
					scenario.setSteps(steps);
					provider.add(new Scenario[] {scenario});
					scenario = new Scenario();
				}

				String[] scenarioDetail = new String[row.getLastCellNum()];
				steps = new ArrayList<String[]>();
				for (int j = 0; j < row.getLastCellNum(); j++) {
					scenarioDetail[j] = row.getCell(j).toString();
				}

				Log.d("add scenario detail: " + Arrays.toString(scenarioDetail));
				scenario.setScenarioDetail(scenarioDetail);

			} else {
				// add 1 index in last scenario detail for test state.
				String[] stepDefinition = new String[row.getLastCellNum() +1];
				for (int j = 0; j < row.getLastCellNum(); j++) {
					if (row.getCell(j).toString().length() < 1) {
						stepDefinition[j] = "";
					} else {
						stepDefinition[j] = row.getCell(j).toString();
					}
					
				}

				Log.d("add step: " + Arrays.toString(stepDefinition));
				steps.add(stepDefinition);
			}
			//Create a loop to print cell values in a row
			// last row
			if (i == rowCount-1) {
				scenario.setSteps(steps);
				provider.add(new Scenario[] {scenario});
			}
		}
		return provider.toArray(new Object[provider.size()][]);

	}
	
    @AfterMethod
    public void takeScreenShotOnFailure(ITestResult testResult) throws IOException { 
    	if (testResult.getStatus() == ITestResult.FAILURE) {    				
       		System.out.println("TS Failed. Status: "+testResult.getStatus()); 
    		} 
    	}
    
    @AfterTest
    public void destroyServer() {
    	server.stopServer();
    }
        
}
