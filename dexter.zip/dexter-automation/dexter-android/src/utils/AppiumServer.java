package utils;

/**
 * This class is use to run appium server on Mac OS programatically for Android emulator.
 * If you are going to run it in different running environment you have to make 
 * some adjustment on path and environment variable. 
 * 
 * @author 
 * Danny Aguswahyudi
 * 
 * */

import java.io.File;
import java.io.IOException;

import org.apache.commons.exec.CommandLine;
import org.apache.commons.exec.DefaultExecuteResultHandler;
import org.apache.commons.exec.DefaultExecutor;

public class AppiumServer {
	// This appium server running on mac environment and need more development to run on Windows
	public void startServer() {
		CommandLine command = null;
		if (OSValidator.isMac()) {
			command = startAppiumServerMac();
		} else if(OSValidator.isWindows()) {
			command = startAppiumServerWindows();
		}

		DefaultExecuteResultHandler resultHandler = new DefaultExecuteResultHandler();
		DefaultExecutor executor = new DefaultExecutor();
		executor.setExitValue(1);
		try {
			executor.execute(command, resultHandler);
			Thread.sleep(12000);
			System.out.println("-----------------------------------------------");
			System.out.println("Appium server started.");
			System.out.println("-----------------------------------------------");
		} catch (IOException e) {
			e.printStackTrace();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	/**
	 * This is a shell command that parsed to java for run appium server on MacOS environment.
	 * 
	 * @return CommandLine object
	 * 
	 */
	public CommandLine startAppiumServerMac() {
		CommandLine command = new CommandLine(
				"/Applications/Appium.app/Contents/Resources/node/bin/node");
		command.addArgument(
				"/Applications/Appium.app/Contents/Resources/node_modules/appium/bin/appium.js",
				false);
		command.addArgument("--address", false);
		command.addArgument("127.0.0.1");
		command.addArgument("--port", false);
		command.addArgument("4723");
		//		command.addArgument("--full-reset", false);
		command.addArgument("--full-reset", true);  
		command.addArgument("--session-override", true);
		command.addArgument("--command-timeout", false);
		command.addArgument("7200");
		command.addArgument("--automation-name", false);
		command.addArgument("Appium");
		command.addArgument("--platform-name", false);
		command.addArgument("Android");

		/**
		 * @param "--app" 
		 * Define an absolute path for appium server to install AUT (Application Under Test) 
		 * Renaming your AUT to 'tokopedia.apk' will help you to leave this source code untouched.
		 * 
		 */

		command.addArgument("--app", false);		
		command.addArgument(System.getProperty("user.home") + File.separator + "AUT" + File.separator + "Android" + File.separator + "tokopedia.apk");	
		command.addArgument("--device-name", false);
		command.addArgument("AndroidTestDevice");
		command.addArgument("--platform-version", false);
		command.addArgument("4.4");

		return command;
	}

	/**
	 * This is a shell command that parsed to java for run appium server on Windows environment.
	 * 
	 * @return CommandLine Object
	 * 
	 * Note :
	 * Due to org.apache.commons.exec.CommandLine, it cannot run node.exe from command line on windows environment
	 * because of whitespace on the default installation directory of node.js.
	 * 
	 * Solution for this problem, we have to add node.js installation directory ("C:\Program Files (x86)\Appium")
	 * to path on environment variable.
	 *  
	 */
	public CommandLine startAppiumServerWindows() {		
		CommandLine command = new CommandLine("cmd");
		command.addArgument("/c");
		command.addArgument("node.exe");
		command.addArgument("\"C:\\Program Files (x86)\\Appium\\node_modules\\appium\\bin\\appium.js\"");
		command.addArgument("--address", false);
		command.addArgument("127.0.0.1");
		command.addArgument("--port", false);
		command.addArgument("4723");
		//		command.addArgument("--full-reset", false);
		command.addArgument("--full-reset", true);  
		command.addArgument("--session-override", true);
		command.addArgument("--command-timeout", false);
		command.addArgument("7200");
		command.addArgument("--automation-name", false);
		command.addArgument("Appium");
		command.addArgument("--platform-name", false);
		command.addArgument("Android");

		/**
		 * @param "--app" 
		 * Define an absolute path for appium server to install AUT (Application Under Test) 
		 * Renaming your AUT to 'tokopedia.apk' will help you to leave this source code untouched.
		 * 
		 */

		command.addArgument("--app", false);		
		command.addArgument(System.getProperty("user.dir") + File.separator + "tokopedia.apk");	
		command.addArgument("--device-name", false);
		command.addArgument("AndroidTestDevice");
		command.addArgument("--platform-version", false);
		command.addArgument("4.4");		
		return command;
	}

	/**
	 * stopServer Method is triggered when after @Test annotation finish.
	 * This method is needed to destroy all the background process that running for appium server.
	 * 
	 */
	public void stopServer() {
		String[] command = null;

		if (OSValidator.isMac()) {
			command = stopAppiumServerMac();
		} else if(OSValidator.isWindows()) {
			command = stopAppiumServerWindows();
		}

		try {
			Runtime.getRuntime().exec(command);
			System.out.println("-----------------------------------------------");
			System.out.println("Appium server stopped.");
			System.out.println("-----------------------------------------------");
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * This method kill node.js process on Mac OS that running appium server to stop appium server services
	 * 
	 * @return String[]
	 */
	public String[] stopAppiumServerMac() {
		String[] command = {
				"/usr/bin/killall", 
				"-KILL", 
				"node"
		};
		return command;
	}

	/**
	 * This method kill node.js task on Windows OS that running appium server to stop appium server services
	 * 
	 * @return String[]
	 */
	public String[] stopAppiumServerWindows() {
		String[] command = {
				"taskkill", 
				"/F", 
				"/IM", 
				"node.exe"
		};
		return command;
	}

}
