package report;

import java.io.File;
import java.io.IOException;
import java.util.Properties;

import javax.activation.CommandMap;
import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.activation.FileDataSource;
import javax.activation.MailcapCommandMap;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;



public class SendEmailReport {

	public static void _send (String mailAddress, String sheet) throws IOException{
		final String username = "dexter.report@tokopedia.com";
		final String password = "DexterLaboratory2015";

		MailcapCommandMap mc = (MailcapCommandMap) CommandMap.getDefaultCommandMap(); 
		mc.addMailcap("image/png;; x-java-content-handler=com.sun.mail.handlers.image_png"); 


		Properties props = new Properties();
		props.put("mail.smtp.auth", "true");
		props.put("mail.smtp.starttls.enable", "true");
		props.put("mail.smtp.host", "smtp.gmail.com");
		props.put("mail.smtp.port", "587");

		Session session = Session.getInstance(props,
				new javax.mail.Authenticator() {
			protected PasswordAuthentication getPasswordAuthentication() {
				return new PasswordAuthentication(username, password);
			}
		});

		try {
			MimeMessage message = new MimeMessage(session);
			message.setFrom(new InternetAddress("qa@tokopedia.com"));
			message.setRecipients(Message.RecipientType.TO,
					InternetAddress.parse(mailAddress));
			
			// list of cc mail addresses
			message.setRecipients(Message.RecipientType.CC, 
					InternetAddress.parse(
							"danny.aguswahyudi@tokopedia.com" + "," +
									"hayi.nukman@tokopedia.com" + "," +
									"lauren.vicky@tokopedia.com"
							)
					);
			message.setSubject("Dexter Android Automation Report");

			String file = System.getProperty("user.dir")+ File.separator + "target" + File.separator + "surefire-reports" + File.separator + "Dexter-ExtentReport.html";
			String fileName = "Dexter-ExtentReport.html";
			DataSource source = new FileDataSource(file);

			String pieChartFile = System.getProperty("user.dir") + File.separator + "testng-xslt" + File.separator + "overview-chart.jpg";
			String pieChartFileName = "Chart.jpg";
			DataSource chartSource = new FileDataSource(pieChartFile);

			File reader = new File(System.getProperty("user.dir")+ File.separator + "testng-xslt" + File.separator + "overview.html");

			Document reportDoc = Jsoup.parse(reader, "UTF-8", "");
			String emailBody = reportDoc.toString();

			MimeBodyPart parameters = new MimeBodyPart();
			String parametersHTML = 
					"<h2>Dexter test information : </h2>"
							+ "<table>"
							//		        		+ "<tr>"
							//			        		+ "<td>URL</td>"
							//			        		+ "<td>" + url + "</td>"
							//		        		+ "</tr>"
							//		        		+ "<tr>"
							//			        		+ "<td>Browser</td>"
							//			        		+ "<td>" + browser + "</td>"
							//		        		+ "</tr>"
							+ "<tr>"
							+ "<td>Test Suite</td>"
							+ "<td>" + sheet + "</td>"
							+ "</tr>"
							+ "</table>";
			parameters.setContent(parametersHTML, "text/html");

			MimeBodyPart graphInline = new MimeBodyPart();
			String graphInlineHTML = "<h1>Test Result</h1><img src=\"cid:image\">";
			graphInline.setContent(graphInlineHTML, "text/html");


			MimeBodyPart textPart = new MimeBodyPart();
			textPart.setContent(emailBody, "text/html");

			MimeBodyPart attachPNGPart = new MimeBodyPart();
			attachPNGPart.setDataHandler(new DataHandler(chartSource));
			attachPNGPart.setHeader("Content-ID", "<image>");
			attachPNGPart.setFileName(pieChartFileName);

			MimeBodyPart attachPart = new MimeBodyPart();
			attachPart.setDataHandler(new DataHandler(source));
			attachPart.setFileName(fileName);

			Multipart multipart = new MimeMultipart();
			multipart.addBodyPart(graphInline);
			multipart.addBodyPart(attachPNGPart);
			multipart.addBodyPart(textPart);
			multipart.addBodyPart(parameters);
			multipart.addBodyPart(attachPart);

			message.setContent(multipart);

			System.out.println("NOW SENDING EMAIL");

			Transport.send(message);

			System.out.println("EMAIL HAS BEEN SENT");

		} catch (MessagingException e) {
			e.printStackTrace();
		}

	}
}