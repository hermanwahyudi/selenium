package action;

import io.appium.java_client.android.AndroidDriver;

import java.io.File;
import java.util.HashMap;
import java.util.List;
import java.util.Properties;
import java.util.Random;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.internal.TouchAction;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.asserts.Assertion;
import org.testng.asserts.SoftAssert;

import utils.Tag;

public class KeywordAction {
	private String errorMessage = "[%s] [operation: %s] Element with criteria: '%s' is not exist"; // errorMessage: used for failed positive assertion error messages.
	private String negativeErrorMessage = "[operation: %s] Element with criteria: '%s' is exist"; // negativeErrorMessage: used for failed negative assertion error message

	// reporter log 
	private String keywordNotRegistered = "the operation keyword --- '%s' --- is NOT REGISTERED IN THE FRAMEWORK---";

	SoftAssert softAssert;
	Assertion hardAssert;
	Assertion doAssert;

	AndroidDriver<WebElement> driver;
	
	WebDriverWait wait;
	TouchAction finger = null;
	String text=null;
	WebElement element = null;
	List<WebElement> elements;
	Select dropdown; 
	File pic;
	JavascriptExecutor js;
	HashMap<String, Double> swipeObject; // for swiping
	HashMap<String, String> scrollObject; // for scrolling

	public KeywordAction(AndroidDriver<WebElement> driver){
		this.driver = driver;
		softAssert = new SoftAssert();
		hardAssert = new Assertion();
	}

	private boolean isElementExist(Properties p, String objectName) {
		try {
			driver.findElement(By.xpath(p.getProperty(objectName)));
		} catch (Exception e) {
			return false;
		}
		return true;
	}

	public void perform(Properties p, String ts_id, String operation,String objectName, String value, String tags) throws Exception {
		System.out.println("["+ ts_id +"]executing operation "+operation+" at "+objectName + " with value " + value);

		if (tags != null && tags.toLowerCase().contains(Tag.CONTINUE_ON_FAIL)) {
			doAssert = softAssert;
		} else {
			doAssert = hardAssert;
		}

		boolean isElementExist = isElementExist(p, objectName);
		if (isElementExist) {
			element = driver.findElement(By.xpath(p.getProperty(objectName)));
		}		

		switch (operation.toUpperCase()) {
		case "CLICK":
			//Perform click
			try {
				if(objectName.length() > 1) {
					this.element.click();
				} else if (value.length() >= 4){
					driver.findElement(By.xpath("//*[contains(@text,'" + value + "')]")).click();
				}
			} catch (Exception e) {
				doAssert.assertTrue(false, String.format(errorMessage, ts_id, operation, p.getProperty(objectName).toString()));
			}
			break;
		case "SWIPE_UP":
			driver.swipe(500,1000,500,500,2000);
			Thread.sleep(1000);
			break;
		case "SWIPE_DOWN":
			driver.swipe(500, 500, 500, 1000, 2000);			
			Thread.sleep(1000);
			break;
		case "SWIPE_RIGHT":
			driver.swipe(200,500,700,500,250);
			Thread.sleep(1000);
			break;
		case "SWIPE_LEFT":
			driver.swipe(700,500,200,500,250);
			Thread.sleep(1000);
			break;
			// scroll to text that contain the value
		case "SCROLL_TO":
			driver.scrollTo(value);
			break;
			// scrollTo text that contain the value and then click it	
		case "SCROLL_TO_CLICK":
			driver.scrollTo(value).click();
			break;
		case "INPUT":
			//Set text on control
			doAssert.assertTrue(isElementExist, String.format(errorMessage, ts_id, operation, p.getProperty(objectName).toString()));
			try {
				this.element.clear();
				this.element.sendKeys(value.replaceAll("\\.0*$", ""));
				driver.hideKeyboard();
			} catch (Exception e) {
				doAssert.assertTrue(false, String.format(errorMessage, ts_id, operation, p.getProperty(objectName).toString()));
			}			
			break;
		case "SLEEP":
//			wait = new WebDriverWait(driver, 5);
			Thread.sleep(5000);
			break;
		case "ASSERT_TRUE" :
			text = this.element.getText();
			doAssert.assertTrue(text.contains(value));
			break;
		case "ASSERT_FALSE" :
			text = this.element.getText();
			doAssert.assertFalse(text.contains(value));
			break;
		case "CHECK_TEXT":
			if (value != null) { 				
				this.element = driver.findElement(By.name(value));
			}
			doAssert.assertEquals(this.element.getText(), value);
			break;
		case "ELEMENT_EXIST":			
			doAssert.assertTrue(isElementExist, String.format(errorMessage, ts_id, operation, p.getProperty(objectName).toString()));
			break;
		case "ELEMENT_NOT_EXIST":			
			doAssert.assertFalse(isElementExist, String.format(negativeErrorMessage, ts_id, operation, p.getProperty(objectName).toString()));
			break;
		case "WAIT_FOR":	
			wait = new WebDriverWait(driver, 10);
			wait.until(ExpectedConditions.visibilityOf(this.element));
			doAssert.assertTrue(isElementExist, String.format(errorMessage, ts_id, operation, p.getProperty(objectName).toString()));
			break;
		case "RANDOM_RECEIPT" :
			StringBuilder sb = new StringBuilder(9);
			Random rnd = new Random();
			int number = rnd.nextInt((999999 - 100000) + 1) + 100000;
			String range = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";

			for( int i = 0; i < 3; i++ ) 
				sb.append(range.charAt(rnd.nextInt(range.length())));

			sb.append(String.valueOf(number));
			perform(p,ts_id, "input",objectName, sb.toString(), tags);
			break;
		case"RESTART_APP":
			driver.resetApp();
			break;
		default:
//			Reporter.log(String.format(keywordNotRegistered, operation));
			Assert.fail(String.format(keywordNotRegistered, operation));
			break;
		}
	}


}