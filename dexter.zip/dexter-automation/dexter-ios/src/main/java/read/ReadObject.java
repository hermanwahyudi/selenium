package read;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import runTest.utils.Log;

public class ReadObject {

	
	static String propDir = File.separator + "src" + File.separator + "main"+ File.separator +"java" + File.separator + "objects" + File.separator;

	public Properties getObjectRepository() throws IOException{
		//Read object repository file
		Properties p = new Properties();
		InputStream stream = new FileInputStream(new File(System.getProperty("user.dir")+ propDir + "object.properties"));
		//load all objects
		p.load(stream);
		return p;
	}

	public Properties getObjectRepository(String prop) throws IOException {
		//Read object repository file
		Properties p = new Properties();
		InputStream stream = new FileInputStream(new File(System.getProperty("user.dir")+ propDir + prop));
		p.load(stream);
		return p;
	}
	
	public static boolean checkPropertiesExist(String prop) {
		try {
			File f = new File(new File(System.getProperty("user.dir") + propDir), prop);
			Log.d(f.getAbsolutePath());
			Log.d("" + f.exists());
			return f.exists();
		} catch (Exception e) {
			Log.warn("Properties: " + prop + " not exist.");
		}
		return false;
	}

}
