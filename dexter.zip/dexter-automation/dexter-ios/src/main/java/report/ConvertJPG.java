package report;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.OutputStream;

import org.apache.batik.transcoder.TranscoderException;
import org.apache.batik.transcoder.TranscoderInput;
import org.apache.batik.transcoder.TranscoderOutput;
import org.apache.batik.transcoder.image.JPEGTranscoder;

import runTest.utils.Log;

public class ConvertJPG {

	public static void _launch() throws Exception {
		Log.debug("CONVERTING REPORT TO EMAILABLE REPORT");
		JPEGTranscoder transcoder = new JPEGTranscoder();
		transcoder.addTranscodingHint(JPEGTranscoder.KEY_QUALITY, new Float(.9));

		TranscoderInput input = new TranscoderInput(new FileInputStream(System.getProperty("user.dir")+"//testng-xslt//overview-chart.svg"));
		OutputStream ostream = new FileOutputStream(System.getProperty("user.dir")+"//testng-xslt//overview-chart.jpg");
		TranscoderOutput output = new TranscoderOutput(ostream);

		try {
			transcoder.transcode(input, output);
		} catch (TranscoderException e) { 
			Log.error("error*************************************************************************************");
			e.printStackTrace();
		}
		Log.debug("CONVERSION TO EMAILABLE REPORT DONE");
		ostream.close();
	}

}
