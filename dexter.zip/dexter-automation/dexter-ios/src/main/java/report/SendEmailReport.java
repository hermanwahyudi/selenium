package report;

import java.io.File;
import java.io.IOException;
import java.util.Properties;

import javax.activation.CommandMap;
import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.activation.FileDataSource;
import javax.activation.MailcapCommandMap;
import javax.mail.Message;
import javax.mail.Message.RecipientType;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;

import runTest.utils.Log;



public class SendEmailReport {

	public static void _send(String sheet, String app, String platformProf) throws IOException{
		final String username = "dexter.report@tokopedia.com";
		final String password = "DexterLaboratory2015";

		MailcapCommandMap mc = (MailcapCommandMap) CommandMap.getDefaultCommandMap(); 
		mc.addMailcap("image/png;; x-java-content-handler=com.sun.mail.handlers.image_png"); 


		Properties props = new Properties();
		props.put("mail.smtp.auth", "true");
		props.put("mail.smtp.starttls.enable", "true");
		props.put("mail.smtp.host", "smtp.gmail.com");
		props.put("mail.smtp.port", "587");

		Session session = Session.getInstance(props,
				new javax.mail.Authenticator() {
			protected PasswordAuthentication getPasswordAuthentication() {
				return new PasswordAuthentication(username, password);
			}
		});

		try {

			MimeMessage message = new MimeMessage(session);
			message.setFrom(new InternetAddress("dexter.report@tokopedia.com"));
//			message.setFrom(new InternetAddress("hayi.nukman@tokopedia.com"));
//			message.setRecipients(Message.RecipientType.TO,
//					InternetAddress.parse(mailAddress));
			// list of cc mail addresses
			message.setRecipient(RecipientType.TO, new InternetAddress("qa@tokopedia.com"));
			message.setRecipients(Message.RecipientType.CC, 
					InternetAddress.parse(
							"danny.aguswahyudi@tokopedia.com" + "," +
									"hayi.nukman@tokopedia.com"
							)
					);
			message.setSubject("Dexter iOS Automation Reporting!");

			String file = System.getProperty("user.dir")+ File.separator + "target" + File.separator + "surefire-reports" + File.separator + "Dexter-ExtentReport.html";
			String fileName = "Dexter-ExtentReport.html";
			DataSource source = new FileDataSource(file);

			String pieChartFile = System.getProperty("user.dir") + File.separator + "testng-xslt" + File.separator + "overview-chart.jpg";
			String pieChartFileName = "Chart.jpg";
			DataSource chartSource = new FileDataSource(pieChartFile);

			File reader = new File(System.getProperty("user.dir")+ File.separator + "testng-xslt" + File.separator + "overview.html");

			Document reportDoc = Jsoup.parse(reader, "UTF-8", "");
			String emailBody = reportDoc.toString();

			MimeBodyPart parameters = new MimeBodyPart();
			String parametersHTML = 
					"<h2>Dexter test information : </h2>"
							+ "<table>"
							+ "<tr>"
							+ "<td>AUT</td>"
							+ "<td>: " + app + "</td>"
							+ "</tr>"
							+ "<tr>"
							+ "<td>Additional Properties</td>"
							+ "<td>: " + platformProf + "</td>"
							+ "</tr>"
							+ "<tr>"
							+ "<td>Sheet</td>"
							+ "<td>: " + sheet + "</td>"
							+ "</tr>"
							+ "</table>";
			parameters.setContent(parametersHTML, "text/html");

			MimeBodyPart graphInline = new MimeBodyPart();
			String graphInlineHTML = "<h1>Test Result</h1><img src=\"cid:image\">";
			graphInline.setContent(graphInlineHTML, "text/html");


			MimeBodyPart textPart = new MimeBodyPart();
			textPart.setContent(emailBody, "text/html");

			MimeBodyPart attachPNGPart = new MimeBodyPart();
			attachPNGPart.setDataHandler(new DataHandler(chartSource));
			attachPNGPart.setHeader("Content-ID", "<image>");
			attachPNGPart.setFileName(pieChartFileName);

			MimeBodyPart attachPart = new MimeBodyPart();
			attachPart.setDataHandler(new DataHandler(source));
			attachPart.setFileName(fileName);

			Multipart multipart = new MimeMultipart();
			multipart.addBodyPart(graphInline);
			multipart.addBodyPart(attachPNGPart);
			multipart.addBodyPart(textPart);
			multipart.addBodyPart(parameters);
			multipart.addBodyPart(attachPart);

			message.setContent(multipart);

			Log.debug("NOW SENDING EMAIL");

			Transport.send(message);

			Log.debug("EMAIL HAS BEEN SENT");

		} catch (MessagingException e) {
			e.printStackTrace();
		}

	}
}
