package report;

import java.io.File;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.apache.tools.ant.BuildException;
import org.apache.tools.ant.DefaultLogger;
import org.apache.tools.ant.Project;
import org.apache.tools.ant.ProjectHelper;
import org.w3c.dom.Node;

import runTest.ExecuteTestCase;
import runTest.utils.Log;

import org.w3c.dom.Document;
import org.w3c.dom.Element;

public class CreateGraphicReport {
	
	public static void _execute(){
		File buildFile = new File(System.getProperty("user.dir")+"\\build.xml");
		try {
			changeTestName();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		Project p = new Project();
		p.setUserProperty("ant.file", buildFile.getAbsolutePath());		
		DefaultLogger consoleLogger = new DefaultLogger();
		consoleLogger.setErrorPrintStream(System.err);
		consoleLogger.setOutputPrintStream(System.out);
		consoleLogger.setMessageOutputLevel(Project.MSG_INFO);
		p.addBuildListener(consoleLogger);

		try {
			p.fireBuildStarted();
			p.init();
			ProjectHelper helper = ProjectHelper.getProjectHelper();
			p.addReference("ant.projectHelper", helper);
			helper.parse(p, buildFile);
			p.executeTarget("generateReport");
			p.fireBuildFinished(null);
		} catch (BuildException e) {
			p.fireBuildFinished(e);
		}
	}
	
	static private void changeTestName() throws Exception {
		String sheet = null;
		if (sheet == null && System.getProperty(ExecuteTestCase.MVN_SHEET) != null) {
			sheet = System.getProperty(ExecuteTestCase.MVN_SHEET);
		}
		
		File report = new File(System.getProperty("user.dir")+File.separator + "target" + File.separator + "surefire-reports" +
				File.separator + "testng-results.xml");
		
		if (report.exists() && report.canWrite()) {
			DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
			Document doc = docBuilder.parse(report.getAbsolutePath());

			// Get the root element
			Node test = doc.getElementsByTagName("test").item(0);
			Element el = (Element) test;
			if (el != null) {
				Log.e("Test Name: " + el.getAttribute("name"));
				el.setAttribute("name", "Sheet: " + sheet);
				Log.e("Test Name: " + el.getAttribute("name"));
				Transformer transformer = TransformerFactory.newInstance().newTransformer();
                transformer.setOutputProperty(OutputKeys.INDENT, "yes");

                // initialize StreamResult with File object to save to file
                StreamResult result = new StreamResult(report.getAbsolutePath());
                DOMSource source = new DOMSource(doc);
                transformer.transform(source, result);
			}
			
		}
	}

}
