package action;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.SwipeElementDirection;
import io.appium.java_client.ios.IOSDriver;
import io.appium.java_client.ios.IOSElement;
import io.appium.java_client.remote.HideKeyboardStrategy;
import runTest.ExecuteTestCase;
import runTest.utils.Log;
import runTest.utils.XPathUtils;

import java.io.File;
import java.util.HashMap;
import java.util.List;
import java.util.Properties;
import java.util.Random;
import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
//import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import org.testng.asserts.Assertion;
import org.testng.asserts.SoftAssert;

//@Listeners(listener.DexterTestListener.class)
public class KeywordAction {
	// errorMessage: used for failed positive assertion error messages.
	private String errorMessage = "[operation: %s] Element with criteria: '%s' is not exist";
	private String errorMessageNegative = "[operation: %s] Element with criteria: '%s' is exist";
	private String errorMessageSoftAssert = "[operation: %s] Soft assert is ON. and Element with criteria: '%s' is not exist, DO NOTHING!";
	// negativeErrorMessage: used for failed negative assertion error message
	private String negativeErrorMessage = "[operation: %s] Element with criteria: '%s' is exist";

	// reporter log 
	private String keywordNotRegistered = "the operation keyword --- %s --- is NOT REGISTERED IN THE FRAMEWORK---";
	private String keywordNotSupported = "the operation keyword --- %s --- is NOT YET SUPPORTED FOR MOBILE AUTOMATION---";



	SoftAssert softAssert;
	Assertion hardAssert;
	Assertion doAssert;

	AppiumDriver driver;
	String bodyText=null;
	WebElement element = null;
	List<WebElement> elements;
	boolean isSoftAssertOn = false;
	//	Select dropdown;
	
	public enum Swipe {
		left, right, top, bottom
	}



	public KeywordAction(AppiumDriver driver){
		this.driver = driver;

		// using soft assert and hard assert to handle test tags.
		softAssert = new SoftAssert();
		hardAssert = new Assertion();
	}

	//	public void perform(Properties p,String operation,String objectName, String value) throws Exception{
	//		System.out.println("executing "+operation+" at "+objectName);
	//		switch (operation.toUpperCase()) {
	//		case "CLICK":
	//			//Perform click
	//			driver.findElement(By.xpath(p.getProperty(objectName))).click();
	//			break;
	//		case "DROPDOWNCLICK":
	//			dropdown = new Select(driver.findElement(By.xpath(p.getProperty(objectName))));
	//			dropdown.selectByVisibleText(value);
	//			//element.sendKeys(Keys.ENTER);
	//			break;
	//		case "INPUT":
	//			//Set text on control
	//			driver.findElement(By.xpath(p.getProperty(objectName))).clear();
	//			driver.findElement(By.xpath(p.getProperty(objectName))).sendKeys(value.replaceAll("\\.0*$", ""));
	//			break;			
	//		case "NAVIGATE":
	//			//Get url of application
	//			driver.get(p.getProperty("url")+value);
	//			break;
	//		case "UPLOADPIC":
	//			File pic = new File(value);		
	//			driver.findElement(By.xpath(p.getProperty(objectName))).sendKeys(pic.getPath());
	//			break;
	//		case "SLEEP":
	//			Thread.sleep(10000);
	//			break;
	//		case "CHECKVALUE":
	//			String ExpectedValue = value;
	//			String Get_Value = driver.findElement(By.xpath(p.getProperty(objectName))).getText();
	//			Assert.assertEquals(Get_Value, ExpectedValue);
	//			break;
	//		case "FINDELEMENTS":
	//			elements = driver.findElements(By.xpath(p.getProperty(objectName)));
	//			Assert.assertFalse(elements.isEmpty());
	//			break;
	//		case "FINDEMPTYELEMENTS":
	//			elements = driver.findElements(By.xpath(p.getProperty(objectName)));
	//			Assert.assertTrue(elements.isEmpty());
	//			break;
	//		case "ELEMENTDISPLAYED":
	//			element = driver.findElement(By.xpath(p.getProperty(objectName)));
	//			Assert.assertTrue(element.isDisplayed());
	//			break;
	//		case "WAITFOR":
	//			element = driver.findElement(By.xpath(p.getProperty(objectName)));
	//			WebDriverWait wait = new WebDriverWait(driver, 10);
	//			wait.until(ExpectedConditions.visibilityOf(element));
	//			break;
	//		case "ASSERTTRUE":
	//			bodyText = driver.findElement(By.tagName("body")).getText();
	//			Assert.assertTrue(bodyText.contains(p.getProperty(objectName)));
	//			break;
	//		case "ASSERTFALSE":
	//			bodyText = driver.findElement(By.tagName("body")).getText();
	//			Assert.assertFalse(bodyText.contains(p.getProperty(objectName)));
	//			break;
	//		case "CHECKTITLE":
	//			String ExpectedTitle = value;
	//			String Get_Title=driver.getTitle();
	//			Assert.assertEquals(Get_Title, ExpectedTitle);
	//			break;
	//			/*
	//			 * July 8 2015
	//			 * Author Muhamad Rizki
	//			 * Image validation
	//			 */	
	//		case "CHECKIMAGESOURCE":
	//			element = driver.findElement(By.tagName("img"));
	//			String src = element.getAttribute("src");
	//			Assert.assertFalse(src.contains(p.getProperty(objectName)));
	//			break;
	//			/*
	//			 * July 28 2015
	//			 * Author Muhamad Rizki
	//			 * Select option on web view
	//			 */	
	//		case "SELECTOPTIONDROPDOWN":
	//			element = driver.findElement(By.xpath(p.getProperty(objectName)));
	//			Select preferedItem=new Select(element);
	//			preferedItem.selectByVisibleText(value);
	//			break;
	//		case "CLOSEAPPLICATION":
	//			driver.resetApp();
	//			driver.wait();
	//			break;
	//		case "SCROLLTO":
	//			driver.scrollTo(value);
	//			driver.wait();
	//			break;
	//		case "OPENAPPLICATION":
	//			break;
	//		case "":
	//			break;
	//		default:
	//			Reporter.log("the operation keyword --- "+operation+" --- is NOT REGISTERED IN THE FRAMEWORK---");
	//			Assert.fail("KEYWORD NOT RECOGNIZED ---"+operation);
	//			break;
	//		}
	//	}


	/**
	 * modified by: Hayi Nukman
	 * Simplified action perform method, refactoring unused operation on iOS
	 */
//	@Test
//	@ActionInvoker
	public void perform(Properties p,String operation,String objectName, String value, String tags) throws Exception{
		Log.d(String.format("[PERFORM ACTION] executing  '%s' at '%s' with value: %s", operation, objectName, value));
		
		if (tags != null && tags.contains(Tag.CONTINUE_ON_FAIL)) {
			String msg = "[SOFT ASSERT] --- tags contain: continue_on_fail, continue test upon fail. Please see the log message for failing steps...";
			Log.w(msg);
			Reporter.log(msg);
			doAssert = softAssert;
			isSoftAssertOn = true;
		} else {
			doAssert = hardAssert;
		}
		
		String objValue = "";
		if (objectName != null && !objectName.isEmpty()) {
			objValue = p.getProperty(objectName);
		}
		
		By byCriteria = null;
		
		try {
			byCriteria = By.xpath(objValue);
		} catch (Exception e) {
			Log.w("Object not registered");
		}
		
		boolean isCoordinat = false;
		try {
			Pattern pat = Pattern.compile("^\\d*,\\d*");
			Matcher m = pat.matcher(objValue);
			isCoordinat = m.matches();
		} catch (Exception e) {
		}
		

		// checking the element is exist or not
		boolean isElementExist = false;
		if(!isCoordinat && objValue != null && objValue.length()>0) {
			isElementExist = isElementExist(byCriteria);
		}
		// re-initialize element.
		this.element = null;
		if (isElementExist) {
			this.element = driver.findElement(byCriteria);
		}

		switch (operation.toUpperCase()) {
		case "CLICK":
			//Perform click
			if (element == null && isCoordinat) {
				String[] pos = objValue.split(",");
				if (pos != null && pos.length == 2) {
					int x = Integer.parseInt(pos[0]);
					int y = Integer.parseInt(pos[1]);
					driver.tap(1, x, y, 100);
				} else {
					doAssert.fail("unable to tap precisely on position: " + objValue + ". Object bust be containing coordinat value: X,Y positions.");
				}
				break;
			}
			
			if (element == null && value != null && !value.isEmpty()) {
				isElementExist = isElementExist(value, 5);
			}
			
			doAssert.assertTrue(isElementExist, String.format(errorMessage, operation, byCriteria.toString()));
			if (element == null && isSoftAssertOn) {
				Reporter.log(String.format(errorMessageSoftAssert, operation, byCriteria.toString()));
				break;
			}
			// element.click() intermittently failed, using driver.tap() instead.
			// especially when the element is custom element  which is not commonly used for clickable element. 
			
//			this.element.click();
			driver.tap(1, element, 2);
			break;
			
		case "PRECISECLICK":
			/* Precise click on specific location
			 * the object value must be coordinate consist two integer number separated by a comma. 
			 * for example: 342,100
			 * so, in the object properties should be like this one:
			 * object_name=342,100
			 */
			if ((objValue == null|| objValue.isEmpty()) && !isSoftAssertOn) {
				doAssert.fail("unable to tap precisely, object is null");
			} else if ((objValue == null || objValue.isEmpty()) && isSoftAssertOn) {
				Log.w("Object is null, and continue on fail");
			}
			String[] pos = objValue.split(",");
			if (pos != null && pos.length == 2) {
				int x = Integer.parseInt(pos[0]);
				int y = Integer.parseInt(pos[1]);
				driver.tap(1, x, y, 100);
			} else {
				doAssert.fail("unable to tap precisely on position: " + objValue + ". Object bust be containing coordinat value: X,Y positions.");
			}
			break;
//		case "DROPDOWNCLICK":
//			// Not supported on iOS (removing)
//			Reporter.log(String.format(keywordNotSupported, operation));
//			doAssert.fail("KEYWORD NOT SUPPORTED ---"+operation);
//			break;
		case "INPUT":
			doAssert.assertTrue(isElementExist, String.format(errorMessage, operation,byCriteria.toString()));
			if (element == null && isSoftAssertOn) {
				Reporter.log(String.format(errorMessageSoftAssert, operation, byCriteria.toString()));
				return;
			}
			
			/* INPUT actions, used for text modifier element such as text field, or text are.
			 * DO not use this action on custom text modifier element which is based from Text view class or other 
			 * non text modifier class.
			 * Using setValue instead of sendKey.
			 */
			
			// need to click the element before passing input.
			//			driver.tap(1, element, 500);
			//			this.element.click();
			//			Thread.sleep(1000);
			this.element.clear();
//			this.element.sendKeys(value.replaceAll("\\.0*$", ""));
			((IOSElement)this.element).setValue(value.replaceAll("\\.0*$", ""));
			break;			
		case "SENDKEY":
			doAssert.assertTrue(isElementExist, String.format(errorMessage, operation,byCriteria.toString()));
			if (element == null && isSoftAssertOn) {
				Reporter.log(String.format(errorMessageSoftAssert, operation, byCriteria.toString()));
				return;
			}
			
			/* SENDKEY similar to INPUT actions, used for any element which is need to do keyboard actions on it. 
			 */
			
			// need to click the element before passing input.
			driver.tap(1, element, 100);
			Thread.sleep(1000);
			this.element.clear();
			this.element.sendKeys(value.replaceAll("\\.0*$", ""));
			
			break;	
		case "TYPE":
			/* Similar to INPUT and SENDKEY, but this action is using javascript executor to send the key/value.
			 * This action is could be use on any element which having keyboard popped up when tapping it, regardless 
			 * what type of these element. 
			 * On iOS cases, UIASerachBar is the only element is unable to do sendKey or setValue from appium, we need to do 
			 * workaround using javascript executor to send text on it.
			 */
			doAssert.assertTrue(isElementExist, String.format(errorMessage, operation,byCriteria.toString()));
			if (element == null && isSoftAssertOn) {
				Reporter.log(String.format(errorMessageSoftAssert, operation, byCriteria.toString()));
				return;
			}
			// focus on search UIASerachBar to display keyboard
			driver.tap(1, element, 500);
			JavascriptExecutor jse = (JavascriptExecutor) driver;
			jse.executeScript("UIATarget.localTarget().frontMostApp().keyboard().typeString(\""+value+"\");", "");
			
			break;
		
		case "SLEEP":
			int timeout = 5;
			try {
				if (value != null && !value.isEmpty()) {
					timeout = Integer.parseInt(value);
				}
			} catch (Exception e) {
			}
			timeout *= 1000;
			Thread.sleep(timeout);

			break;
		case "CHECKVALUE":
			String expectedValue = value;
			doAssert.assertTrue(isElementExist, String.format(errorMessage, operation,byCriteria.toString()));
			if (element == null && isSoftAssertOn) {
				Reporter.log(String.format(errorMessageSoftAssert, operation, byCriteria.toString()));
				return;
			}
			String actualValue = element.getText();
			doAssert.assertEquals(actualValue, expectedValue);
			break;
		case "FINDELEMENTS":
			elements = driver.findElements(By.xpath(p.getProperty(objectName)));
			doAssert.assertFalse(elements.isEmpty());
			break;
		case "FINDELEMENT":
			doAssert.assertTrue(isElementExist, String.format(errorMessage, operation,byCriteria.toString()));
			break;
		case "FINDEMPTYELEMENTS":
			elements = driver.findElements(By.xpath(p.getProperty(objectName)));
			doAssert.assertTrue(elements.isEmpty(), String.format(errorMessage, operation, byCriteria.toString()));
			doAssert.assertTrue(elements.isEmpty());
			break;
		case "ELEMENTDISPLAYED":
			doAssert.assertTrue(isElementExist, String.format(errorMessage, operation, byCriteria.toString()));
			doAssert.assertTrue(element.isDisplayed());
			break;
		case "VERIFYEXIST":
			doAssert.assertTrue(isElementExist, String.format(errorMessage, operation, byCriteria.toString()));
			break;
		case "VERIFYNOTEXIST":
			doAssert.assertFalse(isElementExist, String.format(errorMessageNegative, operation, byCriteria.toString()));
			break;
		case "WAITFOR":
			// TODO not supported in appium,, need to implement new logic
			Reporter.log(String.format(keywordNotRegistered, operation));
			doAssert.fail("KEYWORD NOT SUPPORTED ---"+operation);
			break;
		case "ACCEPT_ALERT":
			try {
				// first locate for default OK button
				if (value != null && !value.isEmpty() && isElementExist(value, 5)) {
					if (element != null && element.isEnabled()) {
						element.click();
						break;
					}
				}
				
				if (isElementExist("OK",2) || isElementExist("Ok", 2) || isElementExist("Iya", 2)) {
					if (element != null && element.isEnabled()) {
						element.click();
						break;
					}
				}
				// .alert().accept(); will do click on default button, wrong behavior on iOS 9.x (default button is first button which is dismiss button) 
				driver.switchTo().alert().accept();
			} catch (Exception e) {
				Log.w("Alert not present");
			}
			break;
		case "ASSERTTRUE":
			doAssert.assertTrue(isElementExist, String.format(errorMessage, operation, byCriteria.toString()));
			break;
		case "ASSERTFALSE":
			doAssert.assertFalse(isElementExist, String.format(negativeErrorMessage, operation, byCriteria.toString()));
			break;
		case "CHECKTITLE":
			// if title exist, the element should be exist
			doAssert.assertTrue(isElementExist, String.format(errorMessage, operation, byCriteria.toString()));
			break;
		
		case "CLOSEAPPLICATION":
			driver.closeApp();
			break;
		case "SCROLLTO":
			if (isElementExist) {
				Log.i("Scroll with object: " + p.getProperty(objectName));
//				// scroll by object.
				String elementID = ((IOSElement)element).getId();
				JavascriptExecutor js = (JavascriptExecutor) driver;
				js.executeScript("mobile: scrollTo", new HashMap<String, String>() {
					{
						put("element", elementID); 
						}
					});
			} else {
				// scroll by value
				driver.scrollTo(value);
			}
			//			driver.wait();
			break;
		case "OPENAPPLICATION":
			break;
		case "RESETAPP":
			driver.resetApp();
			break;
		case "PICK":
			doAssert.assertTrue(isElementExist, String.format(errorMessage, operation,byCriteria.toString()));
			element.sendKeys(value.trim());
			break;
			
		case "VERIFYTEXT":
			if (element == null && isSoftAssertOn) {
				Reporter.log(String.format(errorMessageSoftAssert, operation, byCriteria.toString()));
				return;
			}
			doAssert.assertTrue(isElementExist, String.format(errorMessage, operation,byCriteria.toString()));
			doAssert.assertEquals(value, element.getText());
			
//			if (objectName == null || objectName.isEmpty() && value != null && !value.isEmpty()) {
//				// locate the text on screen, text should be exist on any attribute of elements on screen.
//				// using XPATH=//*[@*[contains(.,'Hot')]]
//				
//				doAssert.assertTrue(isElementExist(By.xpath(XPathUtils.getContainsXPath(value.trim()))), 
//						String.format(errorMessage, operation,byCriteria.toString()));
//			} else {
//				doAssert.assertTrue(isElementExist, String.format(errorMessage, operation,byCriteria.toString()));
//				doAssert.assertEquals(value, element.getText());
//			}
			break;
		case "VERIFYCONTAINS":
			if (element == null && isSoftAssertOn) {
				Reporter.log(String.format(errorMessageSoftAssert, operation, byCriteria.toString()));
				return;
			}
			doAssert.assertTrue(isElementExist, String.format(errorMessage, operation,byCriteria.toString()));
			boolean contains = element.getText().contains(value);
			doAssert.assertTrue(contains, element.getText() + " not contains any word: " + value);
			break;
		case "VERIFYTEXTEQUAL":
			if (objectName == null || objectName.isEmpty() && value != null && !value.isEmpty()) {
				// locate the text on screen, text should be exist on any attribute of elements on screen.
				// using XPATH=//*[@*[contains(.,'Hot')]]
				
				doAssert.assertTrue(isElementExist(By.xpath(XPathUtils.getContainsXPath(value.trim()))), 
						String.format(errorMessage, operation,byCriteria.toString()));
			} else {
				doAssert.assertTrue(isElementExist, String.format(errorMessage, operation,byCriteria.toString()));
				doAssert.assertEquals(value, element.getText());
			}
			break;
			
		case "SWIPELEFT":
			doAssert.assertTrue(isElementExist, String.format(errorMessage, operation,byCriteria.toString()));
			((IOSElement)element).swipe(SwipeElementDirection.LEFT, 500);
			break;
			
		case "SWIPERIGHT":
			doAssert.assertTrue(isElementExist, String.format(errorMessage, operation,byCriteria.toString()));
			((IOSElement)element).swipe(SwipeElementDirection.RIGHT, 500);
			break;
			
		case "SWIPEUP":
			doAssert.assertTrue(isElementExist, String.format(errorMessage, operation,byCriteria.toString()));
			((IOSElement)element).swipe(SwipeElementDirection.UP, 500);
			break;
			
		case "SWIPEDOWN":
			doAssert.assertTrue(isElementExist, String.format(errorMessage, operation,byCriteria.toString()));
			((IOSElement)element).swipe(SwipeElementDirection.DOWN, 500);
			break;
			//randomreceipt
		case "RANDOMRECEIPT":
			value = generateRandomString(8, false, true);
			// input value into object with new value.
			perform(p, "input", objectName, value, tags);
			break;
//			randomword
		case "RANDOMWORD":
			value = generateRandomString(30, true, false);
			// input value into object with new value.
			perform(p, "input", objectName, value, tags);
			break;
			
		case "RANDOMTYPE":
			value = generateRandomString(30, true, false);
			// input value into object with new value.
			perform(p, "type", objectName, value, tags);
			break;

		default:
			Reporter.log(String.format(keywordNotRegistered, operation));
			doAssert.fail("KEYWORD NOT RECOGNIZED ---"+operation);
			break;
		}
	}
	
	

	private String generateRandomString(int length, boolean space, boolean numOnly) {
		StringBuilder tmp = new StringBuilder();
		for (char ch = '0'; ch <= '9'; ++ch)
			tmp.append(ch);
		if (!numOnly) {
			for (char ch = 'a'; ch <= 'z'; ++ch)
				tmp.append(ch);
		}
		if(space) {
			tmp.append(' ');
		}
		char[] symbols = tmp.toString().toCharArray();
		Random random = new Random();
		int ln = random.nextInt(length) + 9;
		char[] buf = new char[ln];
		for (int idx = 0; idx < buf.length; ++idx) 
			buf[idx] = symbols[random.nextInt(symbols.length)];
		return new String(buf);
	}

	public void softAssertAll() {
//		softAssert.assertAll();
	}


	public boolean isElementExist(String elementName) {
		if (elementName == null || elementName.isEmpty()) return false;
		try {
			element = driver.findElementByAccessibilityId(elementName);
		} catch (Exception e) {
			Log.w("[exception found] Cannot find any element with name: '" + elementName + "'");
			return false;
		}
		return true;
	}
	
	public boolean isElementExist(String elementName, int timeout) {
		if (elementName == null || elementName.isEmpty()) return false;
		driver.manage().timeouts().implicitlyWait(timeout, TimeUnit.SECONDS);
		try {
			element = driver.findElementByAccessibilityId(elementName);
		} catch (Exception e) {
			Log.w("[exception found] Cannot find any element with name: '" + elementName + "'");
			resetTimeout();
			return false;
		}
		resetTimeout();
		return true;
	}
	
	private void resetTimeout() {
		driver.manage().timeouts().implicitlyWait(ExecuteTestCase._implicityWait, TimeUnit.SECONDS);
	}

	public boolean isElementExist(By byCriteria) {
		if (byCriteria == null) return false;
		try {
			driver.findElement(byCriteria);
		} catch (Exception e) {
			Log.w("[exception found] Cannot find any element with criteria: " + byCriteria.toString());
			return false;
		}
		return true;
	}

	public static class Tag {
		public static final String CONTINUE_ON_FAIL = "continue_on_fail"; 
		public static final String SKIP = "skip"; 
	}
	
	
	/* iOS automation HACK
	 * since the soft keyboard is hard to hide, we need to do do workaround for it.
	 * Current approach: 
	 * 1) swipe down fast from mid to top
	 */
	public static void hideiOSKeyboard(AppiumDriver driver, By falbackElement) {
		// get the root view of application
		Dimension screenDimen = driver.findElement(By.xpath("//UIAApplication[1]")).getSize(); 
		int sX = screenDimen.width/2;
		int sY = screenDimen.height/2;
		
		driver.swipe(sX, sY, sY, 10, 100);
		driver.executeScript("mobile: scrollTo", new HashMap<String, String>() {{ put("element", ((IOSElement)driver.findElement(falbackElement)).getId()); }});
	}

}
