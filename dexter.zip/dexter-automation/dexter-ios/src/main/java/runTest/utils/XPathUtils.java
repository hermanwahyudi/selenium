package runTest.utils;

/**
 * XPathUtils. <br>
 * This class to generate XPATH String which used to locate element by its attributes value.
 * Preferred to use unique attribute: name, label, text, or value .
 * 
 * @author hayi
 */
public class XPathUtils {
	static String matchesPattern = "//*[@*='%s']";
	static String containsPattern = "//*[@*[contains(.,'%s')]]";
	
	/**
	 * Get XPATH string of any object with any attribute match the value of: object.<br><br>
	 * Example: <br>
	 * 		element: UIATextField<br> 
	 * 		with attribute: value = Email<br>
	 * 		the XPATH should be: //UIATextField[@value='Email']<br>
	 * 	This method will return: //*[@*='Email']<br>
	 * 
	 * @param object Object to locate
	 * @return XPATH String
	 */
	public static String getMatchesXPath(String object) {
		return String.format(matchesPattern, object);
	}
	
	/**
	 * Get XPATH string of any object with any attribute match the value of: object. <br>
	 * Example: <br>
	 * 		element: UIATextField <br> 
	 * 		with attribute: value = Nama Lengkap. <br>
	 * 		the XPATH could be: //UIATextField[contains(@value,'Nama Lengkap')] <br> 
	 * 	This method will return: //*[@*[contains(.,'Nama Lengkap')]]<br>
	 * <br>
	 * @param object Object to locate
	 * @return XPATH String
	 */
	public static String getContainsXPath(String object) {
		return String.format(containsPattern, object);
	}
}
