package runTest.utils;


import org.apache.commons.exec.CommandLine;
import org.apache.commons.exec.DefaultExecuteResultHandler;
import org.apache.commons.exec.DefaultExecutor;

public class SimulatorUtils {
	
	// xcrun simctl uninstall booted com.tokopedia.Tokopedia
	public static void uninstallTokopediaApp() {  
		 
	    CommandLine command = new CommandLine("xcrun");  
	    command.addArgument("simctl");  
	    command.addArgument("uninstall");  
	    command.addArgument("booted");  
	    command.addArgument("com.tokopedia.Tokopedia");  
	    
	    
	    DefaultExecuteResultHandler resultHandler = new DefaultExecuteResultHandler();  
	    DefaultExecutor executor = new DefaultExecutor();  
	    executor.setExitValue(1);  
	    try {
			executor.execute(command, resultHandler);
			Thread.sleep(5000); 
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}  
	    Log.debug("#### uninstall tokopedia app ####");  
	} 

}
