package runTest;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.xerces.impl.validation.ConfigurableValidationState;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.ITest;
import org.testng.ITestContext;
import org.testng.ITestResult;
import org.testng.Reporter;
import org.testng.SkipException;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import org.testng.reporters.SuiteHTMLReporter;

import action.KeywordAction;
import action.KeywordAction.Tag;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.ios.IOSDriver;
import read.ReadExcelFile;
import read.ReadObject;
import runTest.utils.Log;
import runTest.utils.SimulatorUtils;

public class ExecuteTestCase extends SuiteHTMLReporter {
	// ### CAPABILITIES
	// build properties
	public static String AUT_PATH = "_aut";
	public static String APP_NAME = "_app";
	public static String MVN_SHEET = "sheet";
	public static String MVN_TEST_PLATFORM = "platform";
	public static String MVN_PLAT_VERSION = "version";
	public static String MVN_SCENARIO = "scene";
	boolean isScenarioOnly = false;
	private String selectedScenario = null; 
	
	// NOTE: Default AUT path. Store the AUT on /PATH_TO_HOME/AUT/iOS/Tokopedia.app
	public static final String DEF_APP_DIR = System.getProperty("user.home") + File.separator + "AUT" + File.separator + "iOS" + File.separator;
	public String DEFAULT_APP_PATH = DEF_APP_DIR + "Tokopedia.app"; 	
	// Platform Name
	public static final String PLATFORM_IOS = "iOS";
	public static final String PLATFORM_ANDROID = "Android";	// TODO for next development
	final static int confSheet = 0;
	final static int confApp = 1;
	final static int confProp = 2;
	final static int confDevice = 3;
	final static int confVersion = 4;
	

	public static final int _delayEachStep = 100; // in milliseconds
	public static final int _implicityWait = 25;
	String deviceName = "iPhone 5";
	String platformVersion = "8.4";
	AppiumDriver driver = null;
	String testName;
	String testID;
//	AppiumServer server = new AppiumServer();
	String appPath;
	String sheet;
	List<Scenario[]> defaultProvider; // used for next development: calling specific scenario from inside steps.
	LinkedHashSet<String> unmappedObject;
	KeywordAction action;
	Properties allObjects;
	String platformProperties = null;
	List<Scenario[]> failedProvider;
	Object[][] failedScenarios;
	List<Integer> failedIndex = new ArrayList<>();
	int currentScenario = 0;
	
	
	
	@BeforeTest
	public void runServer() throws IOException, InterruptedException {
		// App paths need to be absolute, or relative to the appium server install dir.
		appPath = null;
		loadSheetAppConf();
		loadMvnProperties();
		
		// Populate properties
		ReadObject object = new ReadObject();
		allObjects =  object.getObjectRepository();
		
		// put all object properties prom platform specific properties. will replace default properties on object.properties.
		if (platformProperties != null && !platformProperties.isEmpty()) {
			Properties p = object.getObjectRepository(platformProperties);
			allObjects.putAll(p);
		}
		
		unmappedObject = new LinkedHashSet<String>();
		
		//cleanup
		SimulatorUtils.uninstallTokopediaApp();
		
	}
	
	
	private void loadMvnProperties() {
		// appPath will be set up when when calling maven with -D_aut=/path/to/app/or/ipa and should be absolute path.
		if (System.getProperty(AUT_PATH) != null && !System.getProperty(AUT_PATH).isEmpty()) {
			appPath = System.getProperty(AUT_PATH, (appPath == null) ? DEFAULT_APP_PATH : appPath); // fallback to DEFAULT_APP_PATH.
		}
		
		if (appPath == null || appPath.isEmpty()) {
			appPath = DEFAULT_APP_PATH;
		}
		
		if (System.getProperty(MVN_TEST_PLATFORM) != null && !System.getProperty(MVN_TEST_PLATFORM).isEmpty()) {
			deviceName = System.getProperty(MVN_TEST_PLATFORM);
		}
		
		if (System.getProperty(MVN_PLAT_VERSION) != null && !System.getProperty(MVN_PLAT_VERSION).isEmpty()) {
			platformVersion = System.getProperty(MVN_PLAT_VERSION);
		}
		
		if (System.getProperty(MVN_SCENARIO) != null && !System.getProperty(MVN_SCENARIO).isEmpty()) {
			isScenarioOnly = true;
			selectedScenario = System.getProperty(MVN_SCENARIO);
			Log.debug("Executing only scenarios with ID: " + selectedScenario);
		}
		
		if (System.getProperty(APP_NAME) != null && !System.getProperty(APP_NAME).isEmpty()) {
			String appName = System.getProperty(APP_NAME); // fallback to DEFAULT_APP_PATH.
			if (appName != null && !appName.isEmpty()) {
				String filePath = DEF_APP_DIR + appName;
				File f = new File(filePath);
				if (f.exists()) {
					appPath = filePath;
				}
			}
		}
		
	}


	@BeforeMethod
	public void setUp() throws IOException, InterruptedException {
		Log.i("===== setup =====");
		
		DesiredCapabilities caps = new DesiredCapabilities();
		caps.setCapability("platformName", PLATFORM_IOS);
		caps.setCapability("platformVersion", platformVersion); 			//Replace this with your iOS version
		caps.setCapability("deviceName", deviceName); 			//Replace this with your simulator/device version
		caps.setCapability("app", appPath); 					//Replace this with app path in your system
		
		boolean reset = true;
		// iOS only capability
		caps.setCapability("fullReset", reset);
		caps.setCapability("noReset", !reset);
		
		/**
		 * Make sure to disable push notification in the appliaction. 
		 * look for: registerForRemoteNotificationTypes or something like that, and disable it.
		 * enable this code when running app with push notification enabled.
		 */
//		caps.setCapability("waitForAppScript", "$.delay(10000); true; $.acceptAlert();");
		
		driver = new IOSDriver(new URL("http://127.0.0.1:5000/wd/hub"), caps);
		
		action = new KeywordAction(driver);
		
		driver.manage().timeouts().implicitlyWait(_implicityWait, TimeUnit.SECONDS);
		Log.i("===== setup done =====");
	}


	@Parameters({"sheet"})
    @BeforeSuite
    public void getParameters(String sheet) {
    	this.sheet = sheet;
    	
    	if (sheet == null || sheet.isEmpty()) {
    		Log.e("sheet parameters is empty. please provide sheet parameters.");
    	}
    	Log.i("Param sheet: " + sheet);
    	AppiumServer srv = new AppiumServer();
    	try {
			srv.startAppiumServer();
		} catch (IOException | InterruptedException e) {
			e.printStackTrace();
		}
	}
	
	@Test(dataProvider="scenario", priority=1)
	public void testScenario(Object scenario) throws Exception {
		// TODO: need to properly handle tags.
		
		Log.info("======== Running testScenario ========");
		Scenario scene = (Scenario) scenario;
		if (scene.getScenarioDetail() == null) {
			throw new SkipException("[SKIPPING] --- Empty Scenario!!! Skipping ---");
		}
		
		testID = scene.getScenarioDetail()[Scenario.CELL_TS_ID];
		testName = scene.getScenarioDetail()[Scenario.CELL_TESTCASENAME];
		String tags = scene.getScenarioDetail()[Scenario.CELL_TAGS];
		List<String[]> steps = scene.getSteps();
		
		Log.info("Scenario: " + testName + " ID: " + testID);
		unmappedObject.add("#"+ testName);
		if (tags != null && tags.contains(Tag.SKIP)) {
			// skipping test.
			Log.i("--- SKIPPING ---");
			Log.i("--- Test ID: " + testID);
			Log.i("--- Test Name: " + testName);
			Log.i("--- Steps: ");
			for (String[] step : steps) {
				step[Scenario.CELL_STATE] = "SKIP";
				Log.i("-------> " + Arrays.toString(step));
			}
			Reporter.log(String.format("[SKIPPING] Scenario with testID: %s, testName: %s is skipped due to 'skip' tag.\nTags detail: %s",testID, testName, tags));
			throw new SkipException(String.format("[SKIPPING] --- Skipping scenario: %s ---", testName));
		}
		
		Log.i("Number of steps: " + steps.size());
		for (String[] step : steps) { 
			String stepTags = step[Scenario.CELL_TAGS];
			
			// list all unmapped object.
			String object = step[Scenario.CELL_OBJECT];
			String stepID = step[Scenario.CELL_TS_ID];
			String keyword = step[Scenario.CELL_KEYWORD];
			String value = step[Scenario.CELL_VALUE];
			
			if (allObjects.getProperty(object) == null || allObjects.getProperty(object).isEmpty()) {
				Log.warn("Object: " + object + " Not exist");
				unmappedObject.add(object +"=");
				step[Scenario.CELL_STATE] = "UNKNOWN";
			}
			
			if (stepTags != null && stepTags.contains(Tag.SKIP)) {
				Log.i("[LOG] --- SKIPPING STEPS ---");
				Log.i("[LOG] --- Steps: " + Arrays.toString(step) + " ---");
				Log.i("[LOG] --- Continue to next steps ---");
				
				Reporter.log("[SKIPPING] operation: " + Arrays.toString(step) + " is skipped due to 'skip' tag.");
				step[Scenario.CELL_STATE] = "SKIP";
				continue;
			}
			
			
			takeScreenshot(testID + stepID);
			action.perform(allObjects, keyword, object, value, stepTags);
			step[Scenario.CELL_STATE] = "PASS";
			Thread.sleep(_delayEachStep);
		}
		action.softAssertAll();
	}
	
	// Re-Test the failed test cases.
//	@Test(dataProvider="scenario-fail", priority=2)
//	public void testFailedScenario(Object scenario) throws Exception {
//		testScenario(scenario);
//	}
	
	@AfterMethod 
	public void afterScenario(ITestResult testResult) {
		
		String stat = null;
		switch (testResult.getStatus()) {
		case ITestResult.FAILURE:
			stat = "FAILURE";
			failedIndex.add(currentScenario);
			String pageSource = driver.getPageSource();
			if(pageSource != null && !pageSource.isEmpty()) {
				savePageSource(pageSource, testID);
			}
			break;
		case ITestResult.SKIP:
			stat = "SKIPPED";
			break;
		case ITestResult.SUCCESS:
			stat = "SUCCESS";
			break;
		}
		if(testName != null && !testName.isEmpty()) currentScenario++;
		
		driver.quit();
		Log.debug("Test result: [" + stat +"]");
		
		// Uninstall application.
		SimulatorUtils.uninstallTokopediaApp();
		try {
			// delay 5 seconds between test.
			Thread.sleep(5000);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	
	@AfterTest
	public void afterTest() {
//		printUnmappedObject();
	}
	
	private void savePageSource(String pageSource, String name) {
		try {
			String path = System.getProperty("user.dir") + File.separator + 
					"target" + File.separator + 
					"surefire-reports" + File.separator +
					"page-xml" + File.separator;
			File pathDir = new File(path);
			if (!pathDir.exists()) {
				pathDir.mkdirs();
			}
			String filename = name.replaceAll("[^\\p{L}\\p{Nd}]+", "");
			PrintWriter out = new PrintWriter(path + filename + ".txt");
			out.println(pageSource);
			out.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	private void takeScreenshot(String name) {
		File imgfile = driver.getScreenshotAs(OutputType.FILE);
		try {
			String path = System.getProperty("user.dir") + File.separator + 
					"target" + File.separator + 
					"surefire-reports" + File.separator +
					"screenshot" + File.separator;
			File pathDir = new File(path);
			if (!pathDir.exists()) {
				pathDir.mkdirs();
			}
			String filename = name.replaceAll("[^\\p{L}\\p{Nd}]+", "");
			File saveTo = new File(path + filename + ".jpg");
			FileUtils.copyFile(imgfile, saveTo);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

//	@AfterMethod
//	public void takeScreenShotOnFailure(ITestResult testResult) throws IOException { 
//	    if (testResult.getStatus() == ITestResult.FAILURE) {    		
//	    		
//	    System.out.println(testResult.getStatus()); 
//	    File scrFile = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE); 
//	    FileUtils.copyFile(scrFile, new File(System.getProperty("user.dir")+"/test-fail-screenshot/"+testName+"_"+testID+"_screenshot.jpg")); 
//	    } 
//	}


	
	
	private void printUnmappedObject() {
		Log.warn("UNMAPPED OBJECTS");
		System.out.println("#list of unmapped object, just copy and paste this line into object.properties");
		System.out.println("### BEGIN");
		for(String s: unmappedObject) {
			System.out.println(s);
		}
	}

	
	@DataProvider(name="scenario")
	public Object[][] getScenarioDataFromExcel() throws IOException {
		if (this.sheet == null && System.getProperty(MVN_SHEET) != null) {
			this.sheet = System.getProperty(MVN_SHEET); 
		}
		
		ReadExcelFile file = new ReadExcelFile();
		Sheet excelSheet = file.readExcel(System.getProperty("user.dir"),"iOStest.xlsx" , this.sheet);
		int rowCount = excelSheet.getLastRowNum()-excelSheet.getFirstRowNum();
		Scenario scenario = null;
		
		List<Scenario[]> provider = new ArrayList<Scenario[]>();
		List<String[]> steps = null;
		
		for (int i = 0; i < rowCount; i++) {
			//Loop over all the rows
			Row row = excelSheet.getRow(i+1);
			// Check first cell on every row, if first cell is not empty, start new scenario. if empty, continue add steps on current scenario.
			Cell firstCell = row.getCell(0);
			Cell scId = row.getCell(1);
			if (firstCell != null && !firstCell.toString().isEmpty()) {
				
				if (scenario == null) {
					scenario = new Scenario();
				} else {
					if (!scenario.scenarioDetail[Scenario.CELL_TAGS].contains("norecord")) {
						// do not record scenario if contains tag 'norecord'
						scenario.setSteps(steps);
						
						// handle for only selected scenario
						if (isScenarioOnly && selectedScenario.contains(scenario.getScenarioDetail()[Scenario.CELL_TS_ID])) {
							provider.add(new Scenario[] {scenario});
							// scenario found,, finishing.
//							break;
						}
						
						// handle multiple scenarios 
						if (!isScenarioOnly) {
							provider.add(new Scenario[] {scenario});
						}
					}
					scenario = new Scenario();
				} 
				
				String[] scenarioDetail = new String[row.getLastCellNum()];
				steps = new ArrayList<String[]>();
				for (int j = 0; j < row.getLastCellNum(); j++) {
					scenarioDetail[j] = row.getCell(j) == null ? null : row.getCell(j).toString();
				}
				
				Log.d("add scenario detail: " + Arrays.toString(scenarioDetail));
				scenario.setScenarioDetail(scenarioDetail);
				
			} else {
				// add 1 index in last scenario detail for test state.
				String[] stepDefinition = new String[row.getLastCellNum() +1];
				for (int j = 0; j < row.getLastCellNum(); j++) {
					stepDefinition[j] = row.getCell(j) != null? row.getCell(j).toString() : null;
				}
				
				Log.d("add step: " + Arrays.toString(stepDefinition));
				steps.add(stepDefinition);
			}
			//Create a loop to print cell values in a row
			// last row
			if (i == rowCount-1 && !scenario.scenarioDetail[Scenario.CELL_TAGS].contains("norecord")) {
				scenario.setSteps(steps);
				
				if (isScenarioOnly && selectedScenario.contains(scenario.getScenarioDetail()[Scenario.CELL_TS_ID])) {
					provider.add(new Scenario[] {scenario});
					// scenario found,, finishing.
					break;
				}
				// handle multiple scenario
				if (!isScenarioOnly) {
					provider.add(new Scenario[] {scenario});
				}
			}
		}
		defaultProvider = provider;
		//preserver failing scenario.
		failedScenarios = new Object[provider.size()][0];
		
		return provider.toArray(new Object[provider.size()][]);
		
	}
	
	@DataProvider(name="scenario-fail")
	public Object[][] getFailedScenario() throws IOException {
		failedProvider = new ArrayList<>();
		for(int i: failedIndex) {
			Scenario[] s = defaultProvider.get(i);
			failedProvider.add(s);
		}
		System.out.println("getting scenario data");
		return failedProvider.toArray(new Object[defaultProvider.size()][]);
	}
	
	public void loadSheetAppConf() throws IOException {
		if (this.sheet == null && System.getProperty(MVN_SHEET) != null) {
			this.sheet = System.getProperty(MVN_SHEET);
		}
		
		ReadExcelFile file = new ReadExcelFile();
		Sheet excelSheet = file.readExcel(System.getProperty("user.dir"),"iOStest.xlsx" , "app-conf");
		boolean startcomment = false;
		
		for (Row row : excelSheet) {
			if (row.getCell(confSheet) != null && row.getCell(confSheet).getStringCellValue().contentEquals("***") ) {
				startcomment = !startcomment;
			}
			
			if(startcomment) continue;
			
			if (row.getCell(confSheet) != null && row.getCell(confSheet).getStringCellValue().contentEquals(this.sheet) ) {
				
				// App in use; empty use default
				if ( row.getCell(confApp) != null && 
						row.getCell(confApp).getStringCellValue() != null && 
						!row.getCell(confApp).getStringCellValue().isEmpty()) {
					String app= row.getCell(1).getStringCellValue();
					File f = new File(DEF_APP_DIR, app);
					System.out.println(f.getAbsolutePath());
					
					if (f.exists()) {
						this.appPath= f.getAbsolutePath();
					}
				}
				
				// Additional properties
				if (row.getCell(confProp) != null && 
						row.getCell(confProp).getStringCellValue() != null && 
						!row.getCell(confProp).getStringCellValue().isEmpty()) {
					String prop = row.getCell(confProp).getStringCellValue();
					Log.d(prop);
					if(ReadObject.checkPropertiesExist(prop)) {
						this.platformProperties = prop;
					}
				}
				
				// Platform to test
				if (row.getCell(confDevice) != null && 
						row.getCell(confDevice).getStringCellValue() != null && 
						!row.getCell(confDevice).getStringCellValue().isEmpty()) {
					String prop = row.getCell(confDevice).getStringCellValue();
					deviceName = prop;
					
				}
				if (row.getCell(confVersion) != null && 
						row.getCell(confVersion).getStringCellValue() != null && 
						!row.getCell(confVersion).getStringCellValue().isEmpty()) {
					String prop = row.getCell(confVersion).getStringCellValue();
					platformVersion = prop.replace("'", "").replace("\"", "");
					
				}
				
				Log.debug(deviceName + "(" + platformVersion + ")");
			}
		}
		
	}
	
	
	
	public class Scenario {
		public static final int CELL_TESTCASENAME = 0;
		public static final int CELL_TS_ID = 1;
		public static final int CELL_DESCRIPTIONS = 2;
		public static final int CELL_PAGE_NAME = 3;
		public static final int CELL_KEYWORD = 4;
		public static final int CELL_OBJECT = 5;
		public static final int CELL_VALUE = 6;
		public static final int CELL_TAGS = 7;
		public static final int CELL_STATE = 8;
		
		String[] scenarioDetail;
		List<String[]> steps;

		public Scenario() {
			scenarioDetail = new String[8];
			steps = new ArrayList<String[]>();
		}
		
		public void setScenarioDetail(String[] detail) {
			this.scenarioDetail = detail;
		}
		
		public void setSteps(List<String[]> steps) {
			this.steps = steps;
		}

		public String[] getScenarioDetail() {
			return scenarioDetail;
		}

		public List<String[]> getSteps() {
			return steps;
		}
	}

	
	
}
