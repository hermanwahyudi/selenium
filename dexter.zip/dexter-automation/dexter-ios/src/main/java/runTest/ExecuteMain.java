package runTest;

import java.io.File;
import java.io.IOException;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.testng.TestListenerAdapter;
import org.testng.TestNG;

import read.ReadExcelFile;
import read.ReadObject;
import report.ConvertJPG;
import report.CreateGraphicReport;
import report.SendEmailReport;
import runTest.utils.Log;


public class ExecuteMain {
	final static int confSheet = 0;
	final static int confApp = 1;
	final static int confProp = 2;
	final static int confDevice = 3;
	final static int confVersion = 4;
	

	static final int _delayEachStep = 100; // in milliseconds
	String deviceName = "iPhone 5";
	String platformVersion = "8.4";
	String appPath;
	String sheet;
	String platformProperties = null;


	public static void main (String[]args) throws Exception, IOException{
		Log.debug("DEXTER GENERATE REPORT");
		ExecuteMain m = new ExecuteMain();
		m.loadSheetAppConf();


		Log.info("Test Finished");
		CreateGraphicReport._execute();
		try {
			ConvertJPG._launch();
		} catch (Exception e1) {
			e1.printStackTrace();
		}

		/*
		 * @param String mailAddress, String url, String browser, String sheet 
		 * 
		 * */
		
		SendEmailReport._send(m.sheet, m.appPath, m.platformProperties);		
		Log.debug("TOKOPEDIA AUTOMATION TEST SUCCESSFULL");
		Log.debug("EXIT");
		Log.debug("TOKOPEDIA DEXTER VERSION 2.0");	
		
	}
	
	private void loadSheetAppConf() throws IOException {
		if (this.sheet == null && System.getProperty(ExecuteTestCase.MVN_SHEET) != null) {
			this.sheet = System.getProperty(ExecuteTestCase.MVN_SHEET);
		}
		
		ReadExcelFile file = new ReadExcelFile();
		Sheet excelSheet = file.readExcel(System.getProperty("user.dir"),"iOStest.xlsx" , "app-conf");
		boolean startcomment = false;
		
		for (Row row : excelSheet) {
			if (row.getCell(confSheet) != null && row.getCell(confSheet).getStringCellValue().contentEquals("***") ) {
				startcomment = !startcomment;
			}
			
			if(startcomment) continue;
			
			if (row.getCell(confSheet) != null && row.getCell(confSheet).getStringCellValue().contentEquals(this.sheet) ) {
				
				// App in use; empty use default
				if ( row.getCell(confApp) != null && 
						row.getCell(confApp).getStringCellValue() != null && 
						!row.getCell(confApp).getStringCellValue().isEmpty()) {
					String app= row.getCell(1).getStringCellValue();
					File f = new File(ExecuteTestCase.DEF_APP_DIR, app);
					
					if (f.exists()) {
						this.appPath= f.getAbsolutePath();
					}
				}
				
				// Additional properties
				if (row.getCell(confProp) != null && 
						row.getCell(confProp).getStringCellValue() != null && 
						!row.getCell(confProp).getStringCellValue().isEmpty()) {
					String prop = row.getCell(confProp).getStringCellValue();
					if(ReadObject.checkPropertiesExist(prop)) {
						this.platformProperties = prop;
					}
				}
				
				// Platform to test
				if (row.getCell(confDevice) != null && 
						row.getCell(confDevice).getStringCellValue() != null && 
						!row.getCell(confDevice).getStringCellValue().isEmpty()) {
					String prop = row.getCell(confDevice).getStringCellValue();
					deviceName = prop;
					
				}
				if (row.getCell(confVersion) != null && 
						row.getCell(confVersion).getStringCellValue() != null && 
						!row.getCell(confVersion).getStringCellValue().isEmpty()) {
					String prop = row.getCell(confVersion).getStringCellValue();
					platformVersion = prop.replace("'", "").replace("\"", "");
					
				}
			}
		}
		
		if (System.getProperty(ExecuteTestCase.APP_NAME) != null && !System.getProperty(ExecuteTestCase.APP_NAME).isEmpty()) {
			String appName = System.getProperty(ExecuteTestCase.APP_NAME); // fallback to DEFAULT_APP_PATH.
			if (appName != null && !appName.isEmpty()) {
				String filePath = ExecuteTestCase.DEF_APP_DIR + appName;
				File f = new File(filePath);
				if (f.exists()) {
					appPath = filePath;
				}
			}
		}
		
	}


}