package runTest;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.commons.exec.CommandLine;
import org.apache.commons.exec.DefaultExecuteResultHandler;
import org.apache.commons.exec.DefaultExecutor;
import org.apache.commons.exec.PumpStreamHandler;

import runTest.utils.Log;


public class AppiumServer {
	
	public void startAppiumServer() throws IOException, InterruptedException {  
		String shell = System.getProperty("user.dir") + File.separator + "scripts" + File.separator + "appium-device-ios.sh";
	    CommandLine command = new CommandLine(shell);
	    command.addArgument("&");
	    
	    DefaultExecutor executor = new DefaultExecutor();  
	    
	    PumpStreamHandler handler = new PumpStreamHandler(new FileOutputStream("out.txt"), new FileOutputStream("out.txt"));
	    executor.setExitValue(0);  
	    executor.setStreamHandler(handler);
	    executor.execute(command);  
	  
	    Thread.sleep(5000);  

	    Log.debug("=====================");
	    Log.debug("Appium server started");  
	    Log.debug("=====================");
	}  
	  
	public  void stopAppiumServer() throws IOException {  
	    String[] command ={"/usr/bin/killall","-KILL","node"};
	    Runtime.getRuntime().exec(command); 
	    Log.debug("==================");
	    Log.debug("Appium server stop");
	    Log.debug("==================");
	}  
	
	
}