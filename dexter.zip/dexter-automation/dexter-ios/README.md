# Dexter-iOS automation

## Setting up:
- Please use '.app' file which build for Simulator. *Do not use the '.ipa' files which is exported for iOS Devices*.
- save the app file in: /Users/[YOUR_USER]/AUT/iOS/Tokopedia.app

## Starting test

1. First, start the appium server using *'appium-ios.sh'* script in the scripts directory. Run from terninal.
Note: for iOS automation, only ONE appium instance could be run.
2. Start test using: 
> mvn clean test -Dsheet="Sheet name"

for example:

    > mvn clean test -Dsheet="iOS"

## Custom Test parameters
-DlogColor=true|[false]
	Default false. Turn on log colors (Mac/Linux only)

-Dscene="Scene1, Scene2, Scene3,..."
	Test only these scenarios. Do not specify this parameters if all scenarios.
	

## Note
Please don’t hesitate to contact me if you found any problem or development idea for dexter automation system. Contact me via slack *@hayi.tokopedia*.