#!/bin/bash

NODE='/Applications/Appium.app/Contents/Resources/node/bin/node'
APPIUM='/Applications/Appium.app/Contents/Resources/node_modules/appium/bin/appium.js'
PORT=5000
WEBHOOK=5001
ADDR=127.0.0.1
LOGDIR=~/log
LOGFILE=$LOGDIR/appium.log
mkdir -p $LOGDIR

function movelog() {
    if [ -f $LOGFILE ];
    then
        created=$(head -n 1 $LOGFILE |awk '{print $1$2}'|sed -e 's/ //g'|sed -e 's/-//g'|sed -e 's/://g')
        mv $LOGFILE $LOGDIR/appium-$created.log 2> /dev/null >> /dev/null
    fi
}

function startAppium() {
	date +%Y%m%d-%H%M%S
	echo "Starting appium"
#    $NODE $APPIUM 
    $NODE $APPIUM \
		--address $ADDR \
		--port $PORT \
		--session-override \
		--backend-retries 10 \
		--show-ios-log \
		--debug-log-spacing \
		--command-timeout 90 \
		-g $LOGFILE \
        --launch-timeout 50000 >> /dev/null &
}
#startAppium


if [ -z "$1" ]
then
	echo "please use: appium-ios.sh start|stop"
else
	case "$1" in
		"start")
			startAppium
			;;
		"stop")
			echo "Stopping appium server"
			ps aux |grep node |grep ios | grep -v grep |grep -v android |grep -v tail | grep -v vim | grep -v nano | awk '{print "kill -9 " $2}'|bash
            movelog
			;;
		*)
			echo "invalid argument. use: appium-ios.sh start|stop"
			;;
	esac
fi


