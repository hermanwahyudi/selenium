#!/bin/bash

NODE='/Applications/Appium_1.4.13.app/Contents/Resources/node/bin/node'
APPIUM='/Applications/Appium_1.4.13.app/Contents/Resources/node_modules/appium/bin/appium.js'
PORT=5000
ADDR=127.0.0.1
LOGDIR=~/log
LOGFILE=$LOGDIR/appium.log
DEVICE=$(idevice_id -l |head -1)
mkdir -p $LOGDIR
if [ -f $LOGFILE ];
then 
    created=$(head -n 1 $LOGFILE |awk '{print $1$2}'|sed -e 's/ //g'|sed -e 's/-//g'|sed -e 's/://g')
    mv $LOGFILE $LOGDIR/appium-$created.log 2> /dev/null >> /dev/null
fi

function startAppium() {
	date +%Y%m%d-%H%M%S > $LOGFILE
	echo "Starting appium"
#    $NODE $APPIUM 
#    nohup $NODE $APPIUM
#		--show-ios-log \
    SCRIPT="$NODE $APPIUM"
    if [ -n "$DEVICE" ]; then
		SCRIPT="$SCRIPT -U $DEVICE"
    fi
	SCRIPT="$SCRIPT --address $ADDR \
		--port $PORT \
        --native-instruments-lib \
		--session-override \
		--backend-retries 10 \
		--debug-log-spacing \
        --full-reset \
        --debug-log-spacing \
		--command-timeout 90 \
        -g $LOGFILE \
        --launch-timeout 50000"
    echo "Running: $SCRIPT"

    $SCRIPT >> /dev/null &

}
## kill all process using $APPIUM_PORT
killProcessPort() {
    proc=$(lsof -P | grep ':5000' | awk '{print $2}')

    echo "clean up process using port: 5000 $proc"
    kill -9 $proc 2> /dev/null >>/dev/null &
#lsof -P | grep ':$1' | awk '{print $2}' | xargs kill -9
}




## execute
killProcessPort $PORT
sleep 2
startAppium 2>/dev/null >>/dev/null &
sleep 5
#exit 0


#if [ -z "$1" ]
#then
#	echo "please use: appium-ios.sh start|stop"
#else
#	case "$1" in
#		"start")
#			startAppium
#			;;
#		"stop")
#			echo "please stop manually"
#			;;
#		*)
#			echo "invalid argument. use: appium-ios.sh start|stop"
#			;;
#	esac
#fi


