#!/bin/bash
### clean up process using port: 5000 Static port for appium iOS
export APPIUM_PORT='5000'

## kill all process using $APPIUM_PORT
killProcessPort() {
    lsof -P | grep ':$1' | awk '{print $2}' | xargs kill -9
}




## execute
killProcessPort $APPIUM_PORT
