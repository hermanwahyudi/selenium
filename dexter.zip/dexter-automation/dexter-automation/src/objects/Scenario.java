package objects;

import java.util.ArrayList;
import java.util.List;

public class Scenario {
	public static final int CELL_TESTCASENAME = 0;
	public static final int CELL_TS_ID = 1;
	public static final int CELL_DESCRIPTIONS = 2;
	public static final int CELL_PAGE_NAME = 3;
	public static final int CELL_KEYWORD = 4;
	public static final int CELL_OBJECT = 5;
	public static final int CELL_VALUE = 6;
	public static final int CELL_TAGS = 7;
	public static final int CELL_STATE = 8;
	
	String[] scenarioDetail;
	List<String[]> steps;

	public Scenario() {
		scenarioDetail = new String[8];
		steps = new ArrayList<String[]>();
	}
	
	public void setScenarioDetail(String[] detail) {
		this.scenarioDetail = detail;
	}
	
	public void setSteps(List<String[]> steps) {
		this.steps = steps;
	}

	public String[] getScenarioDetail() {
		return scenarioDetail;
	}

	public List<String[]> getSteps() {
		return steps;
	
}

	
	
}
