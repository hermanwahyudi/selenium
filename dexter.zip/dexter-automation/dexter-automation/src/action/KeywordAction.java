package action;

import java.io.File;
import java.util.List;
import java.util.Properties;
import java.util.Random;
import java.util.Set;
import java.util.regex.Pattern;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Reporter;
import org.testng.asserts.Assertion;
import org.testng.asserts.SoftAssert;

import runTest.Utils.Log;
import runTest.Utils.Tag;

public class KeywordAction {

	// errorMessage: used for failed positive assertion error messages.
	private String errorMessage = "[%s] [operation: %s] Element with criteria: '%s' is not exist";
	// negativeErrorMessage: used for failed negative assertion error message
	private String negativeErrorMessage = "[operation: %s] Element with criteria: '%s' is exist";

	// reporter log 
	private String keywordNotRegistered = "the operation keyword --- %s --- is NOT REGISTERED IN THE FRAMEWORK---";
	private String keywordNotSupported 	= "the operation keyword --- %s --- is NOT YET SUPPORTED FOR MOBILE AUTOMATION---";

	SoftAssert softAssert;
	Assertion hardAssert;
	Assertion doAssert;

	WebDriver driver;
	String bodyText=null;
	String text;
	WebElement element = null;
	List<WebElement> elements;
	Select dropdown; 
	File pic;
	String browser;
	String url;
	boolean isSoftAssert = false;

	public KeywordAction(WebDriver driver, String url){
		this.setDriver(driver);
		this.setURL(url);

		softAssert = new SoftAssert();
		hardAssert = new Assertion();
	}

	private void setURL(String url) {
		// TODO Auto-generated method stub
		this.url = url;
	}

	public void setDriver(WebDriver driver) {
		this.driver = driver;
	}

	private String getURL() {
		return this.url;
	}

	public void perform(Properties p, String ts_id, String operation,String objectName, String value, String tags) throws Exception{
		System.out.println("["+ ts_id +"]executing operation "+operation+" at "+objectName + " with value " + value);
		
		if (tags != null && tags.toLowerCase().contains(Tag.CONTINUE_ON_FAIL)) {
			doAssert = softAssert;
//			isSoftAssert = true;
		} else {
			doAssert = hardAssert;
		}
		
		boolean isElementExist = isElementExist(p, objectName);
		if (isElementExist) {
			element = driver.findElement(By.xpath(p.getProperty(objectName)));
		}
		
		switch (operation.toUpperCase()) {
		// click on a certain object
		case "CLICK":
			doAssert.assertTrue(isElementExist, String.format(errorMessage, ts_id, operation, p.getProperty(objectName).toString()));
			//Perform click
			try {
				WebDriverWait wait = new WebDriverWait(driver, 10);
				wait.until(ExpectedConditions.elementToBeClickable(this.element));
				if (objectName != null || !objectName.isEmpty()) {
					this.element.click();
				} else if (value != null || !value.isEmpty()) {
					driver.findElement(By.linkText(value)).click();
				}				
			} catch (Exception e) {
				doAssert.assertTrue(false, String.format(errorMessage, ts_id, operation, p.getProperty(objectName).toString()));
			}
						
			break;
		case "JS_CLICK":
			doAssert.assertTrue(isElementExist, String.format(errorMessage, ts_id, operation, p.getProperty(objectName).toString()));
			JavascriptExecutor executor = (JavascriptExecutor) driver;
			executor.executeScript("arguments[0].click();", this.element);
			break;
		case "DROPDOWNCLICK":			
			doAssert.assertTrue(isElementExist, String.format(errorMessage, ts_id, operation, p.getProperty(objectName).toString()));
			dropdown = new Select(this.element);
			dropdown.selectByVisibleText(value.replaceAll("\\.0*$", ""));
			break;
		case "INPUT":
			doAssert.assertTrue(isElementExist, String.format(errorMessage, ts_id, operation, p.getProperty(objectName).toString()));
			//Set text on control
			try {
				this.element.clear();
				this.element.sendKeys(value.replaceAll("\\.0*$", ""));
			} catch (Exception e) {
				doAssert.assertTrue(false, String.format(errorMessage, ts_id, operation, p.getProperty(objectName).toString()));
			}			
			break;				
		case "NAVIGATE":
			// Navigate to the page tokopedia.com/{value}
			driver.get(this.getURL() + value);
			break;
		case "UPLOAD_PICTURE":
//			pic = new File(value);
			pic = new File(System.getProperty("user.dir") + File.separator + "pictures" + File.separator + value);
			doAssert.assertTrue(isElementExist, String.format(errorMessage, ts_id, operation, p.getProperty(objectName).toString()));
			this.element.sendKeys(pic.getAbsolutePath());
			break;
		case "SLEEP":
			Thread.sleep(5000);
			break;
		case "CHECK_TEXT":
			String ExpectedText = value;
			doAssert.assertTrue(isElementExist, String.format(errorMessage, ts_id, operation, p.getProperty(objectName).toString()));
			String Get_Text = this.element.getText();
			//			System.out.println(Get_Value);
			doAssert.assertEquals(Get_Text, ExpectedText);
			break;
			//			edited start
		case "CHECK_VALUE":
			String ExpectedValue = value;
			doAssert.assertTrue(isElementExist, String.format(errorMessage, ts_id, operation, p.getProperty(objectName).toString()));
			String Get_Value = this.element.getAttribute("value");
			doAssert.assertEquals(Get_Value, ExpectedValue);
			break;
		case "FIND_ELEMENT":
			elements = driver.findElements(By.xpath(p.getProperty(objectName)));
			doAssert.assertFalse(elements.isEmpty());
			break;
		case "ELEMENT_DISPLAYED":
			doAssert.assertTrue(isElementExist, String.format(errorMessage, ts_id, operation, p.getProperty(objectName).toString()));
			doAssert.assertTrue(this.element.isDisplayed());
			break;
		case "WAIT_FOR":
			doAssert.assertTrue(isElementExist, String.format(errorMessage, ts_id, operation, p.getProperty(objectName).toString()));
			WebDriverWait wait = new WebDriverWait(driver, 10);
			wait.until(ExpectedConditions.visibilityOf(this.element));
			break;
		case "ASSERT_TRUE":
			text = this.element.getText();
			doAssert.assertTrue(text.contains(value));
			//bodyText = driver.findElement(By.tagName("body")).getText();
			//doAssert.assertTrue(bodyText.contains(value));
			break;
		case "ASSERT_FALSE":
			bodyText = driver.findElement(By.tagName("body")).getText();
			doAssert.assertFalse(bodyText.contains(value));
			break;
		case "CHECK_TITLE":
			String ExpectedTitle = value;
			String Get_Title=driver.getTitle();
			doAssert.assertEquals(Get_Title, ExpectedTitle);
			break;
		case "CLOSE_BROWSER":
			driver.quit();
			break;
		case "OPENBROWSER":
			break;
		case "SWITCH_BROWSER":
			for(String winHandle : driver.getWindowHandles()){
				driver.switchTo().window(winHandle);	
			}
			break;
		case "RANDOM_RECEIPT" :
			StringBuilder sb = new StringBuilder(9);
			Random rnd = new Random();
			int number = rnd.nextInt((999999 - 100000) + 1) + 100000;
			String range = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";

			for( int i = 0; i < 3; i++ ) 
				sb.append(range.charAt(rnd.nextInt(range.length())));

			sb.append(String.valueOf(number));
			perform(p,ts_id, "input",objectName, sb.toString(), tags);
			break;
		case "SET_URL" :
			driver.get(value);
			break;
		case "CONTAIN" :
			bodyText = driver.findElement(By.tagName("body")).getText();
			doAssert.assertTrue(bodyText.contains(value));
			break;
		case "EXPECTED_URL" :
			doAssert.assertEquals(driver.getCurrentUrl(), value);
			System.out.println(driver.getCurrentUrl());
			break;
		default:
			Reporter.log(String.format(keywordNotRegistered, operation));
			doAssert.fail("KEYWORD NOT RECOGNIZED ---"+operation);
			break;
		}
	}

	private boolean isElementExist(Properties p, String objectName) {
		try {
			driver.findElement(By.xpath(p.getProperty(objectName)));
		} catch (Exception e) {
//			Log.w("Cannot find any element with name " + objectName);
			return false;
		}
		return true;
	}
}
