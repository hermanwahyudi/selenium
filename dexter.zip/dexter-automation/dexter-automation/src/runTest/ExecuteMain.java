package runTest;

import java.io.IOException;

import report.ConvertJPG;
import report.CreateGraphicReport;
import report.SendEmailReport;

public class ExecuteMain {
	
	public static void main (String[]args) throws Exception, IOException {
		System.out.println("DEXTER GENERATE REPORT");
		
//		TestListenerAdapter tla = new TestListenerAdapter();
//		TestNG testng = new TestNG();
//		testng.setTestClasses(new Class[] { ExecuteTestCase.class });
//		testng.setDefaultSuiteName("Automation Custom Suite");
//		testng.addListener(tla);
//		testng.run();
		
		CreateGraphicReport._execute();
		ConvertJPG._launch();
		
		/*
		 * @param String mailAddress, String url, String browser, String sheet 
		 * 
		 * */
		SendEmailReport._send(args[0], args[1], args[2], args[3]);
//		SendEmailReport._send("danny.aguswahyudi@tokopedia.com", "https://www.tokopedia.com/", "chrome", "Prod_Smoke");
//		SendEmailReport._send("danny.aguswahyudi@tokopedia.com");
		System.out.println("TOKOPEDIA AUTOMATION TEST SUCCESSFULL");
		System.out.println("EXIT");
		System.out.println("TOKOPEDIA DEXTER VERSION 2.0");	
	}

}