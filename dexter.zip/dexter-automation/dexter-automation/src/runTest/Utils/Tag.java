package runTest.Utils;

public class Tag {
	public static final String CONTINUE_ON_FAIL = "continue_on_fail"; 
	public static final String SKIP = "skip"; 
}
