package runTest.Utils;


import org.fusesource.jansi.Ansi;
import org.fusesource.jansi.Ansi.Color;


/**
 * Logger class. This class is to generate log based on the log type. 
 * Each log type will be displayed on terminal with different color.
 * How to use:
 * 		Log.e("message") 		--> will display: "[error] message" with '[error]' are displayed in red color
 * 		Log.error("message") 	--> will display: "[error] message" with red color in all message.
 * 
 * @author hayi
 */
public class Log {
	static boolean isColorEnabled = Boolean.valueOf(System.getProperty("logColor"));

	public static void i(String infoMessage) {
		Log.compile("[info] ", Color.BLUE);
		Log.print(infoMessage);
	}

	public static void e(String errorMessage) {
		Log.compile("[error] ", Color.RED);
		Log.print(errorMessage);
	}

	public static void d(String debugMessage) {
		Log.compile("[debug] ", Color.CYAN);
		Log.print(debugMessage);
	}

	public static void w(String warnMessage) {
		Log.compile("[warning] ", Color.YELLOW);
		Log.print(warnMessage);
	}

	public static void p(String message) {
		Log.print(message);
	}



	/**
	 * Default log writer. color, depend on message
	 * @param message
	 */
	public static void print(Object message) {
		System.out.println(message);
	}


	/**
	 * Default info log writer. color: cyan
	 * @param message
	 */
	public static void info(String message) {
		Log.compile("[info] " + message + "\n", Color.BLUE);
	}

	/**
	 * Default debug log writer. color: green
	 * @param message
	 */
	public static void debug(String message) {
		Log.compile("[debug] " + message + "\n", Color.CYAN);
	}

	/**
	 * Default error log writer. color: red
	 * @param message
	 */
	public static void error(String message) {
		Log.compile("[error] " + message + "\n", Color.RED);
	}

	/**
	 * Default error log writer. color: red
	 * @param message
	 */
	public static void warn(String message) {
		Log.compile("[warning] " + message + "\n", Color.YELLOW);
	}

	private static void compile(String message, Ansi.Color color) {
		if (isColorEnabled && Ansi.isEnabled() && Ansi.isDetected())  {
			Ansi text = Ansi.ansi().fg(color).a(message).reset();
			System.out.print(text);
		} else {
			System.out.print(message);
		}
		
	}
	
	public static void t(String message) {
		Log.compile("[info] " + message, Color.CYAN);
	}
}

