package runTest;

import io.selendroid.client.SelendroidDriver;
import io.selendroid.common.SelendroidCapabilities;
import io.selendroid.standalone.SelendroidConfiguration;
import io.selendroid.standalone.SelendroidLauncher;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import objects.Scenario;

import org.apache.commons.io.FileUtils;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.ITestResult;
import org.testng.Reporter;
import org.testng.SkipException;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import org.testng.reporters.SuiteHTMLReporter;

import read.ReadExcelFile;
import read.ReadObject;
import runTest.Utils.Log;
import runTest.Utils.OSValidator;
import runTest.Utils.Tag;
import action.KeywordAction;

public class ExecuteTestCase extends SuiteHTMLReporter {
	WebDriver webdriver = null;
	KeywordAction action;

	String browser;
	String sheet;
	String url;

	String testName;
	String testID;
	String test;
	
	ReadObject object;
	Properties allObjects;

	{
		if (OSValidator.isWindows()) {
			System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir")+ File.separator + "driver" +
					File.separator + "windows" + File.separator + "chromedriver.exe");
		} else if (OSValidator.isMac()) {
			System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir")+ File.separator + "driver" +
					File.separator + "mac" + File.separator + "chromedriver");
		}
	}

	// Recieve parameters from jenkins -> ant build.xml -> testng.xml
	// setUpTest going to be run berfore any test run.
	// Setting up browser and sheet name to test.	
	@Parameters({"browser", "sheet", "url"})
	@BeforeTest
	public void getParameters(String browser, String sheet, String url) {
		this.browser = browser;
		this.sheet = sheet;
		this.url = url;
	}
	
	@BeforeMethod
	public void setUpTest() {    	    	
		switch (this.browser.toLowerCase()) {
		// set webDriver for firefox browser
		case "firefox":
			webdriver = new FirefoxDriver();			
	    	webdriver.manage().window().maximize();
			break;

			// set webDriver for chrome browser
		case "chrome":
			webdriver = new ChromeDriver();
			webdriver.manage().window().maximize();
			break;

			// set webDriver for android browser
		case "androidbrowser":
			SelendroidConfiguration config = new SelendroidConfiguration();
			config.addSupportedApp("selendroid-test-app-0.9.0.apk");
			SelendroidLauncher selendroidServer = new SelendroidLauncher(config);
			selendroidServer.launchSelendroid();

			SelendroidCapabilities caps = new SelendroidCapabilities("io.selendroid.testapp:0.9.0");
			try {
				webdriver = new SelendroidDriver(caps);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			break;	
		default:
			break;
		}

		action = new KeywordAction(webdriver, this.url);
		// read object properties file
		object = new ReadObject();
		try {
			allObjects =  object.getObjectRepository(this.url);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
	}

	// incovationCount is The number of times this method should be invoked
	// dataProvider is the source being use as param by @Test annotation for every invoke
	
	@Test(dataProvider="scenario")
	public void testScenario(Object scenario) throws Exception {
		// TODO: need to properly handle tags.

		Log.info("======== Running testScenario ========");
		Scenario scene = (Scenario) scenario;
		if (scene.getScenarioDetail() == null) {
			throw new SkipException("[SKIPPING] --- Empty Scenario!!! Skipping ---");
		}		
		
		testID = scene.getScenarioDetail()[Scenario.CELL_TS_ID];
		testName = scene.getScenarioDetail()[Scenario.CELL_TESTCASENAME];
		String tags = scene.getScenarioDetail()[Scenario.CELL_TAGS];
		List<String[]> steps = scene.getSteps();

		Log.info("Scenario: " + testName + " ID: " + testID);

		if (tags != null && tags.toLowerCase().contains(Tag.SKIP)) {
			// skipping test.
			Log.i("--- SKIPPING ---");
			Log.i("--- Test ID: " + testID);
			Log.i("--- Test Name: " + testName);
			Log.i("--- Steps: ");
			for (String[] step : steps) {
				Log.i("-------> " + Arrays.toString(step));
			}
			Reporter.log(String.format("[SKIPPING] Scenario with testID: %s, testName: %s is skipped due to 'skip' tag.\nTags detail: %s",testID, testName, tags));
			throw new SkipException(String.format("[SKIPPING] --- Skipping scenario: %s ---", testName));
		}
		
		Log.i("Number of steps: " + steps.size());
		for (String[] step : steps) {
			String stepTags = step[Scenario.CELL_TAGS];
			if (stepTags != null && stepTags.contains(Tag.SKIP)) {
				step[Scenario.CELL_STATE] = "SKIP";
				Log.i("[LOG] --- SKIPPING STEPS ---");
				Log.i("[LOG] --- Steps: " + Arrays.toString(step) + " ---");
				Log.i("[LOG] --- Continue to next steps ---");

				Reporter.log("[SKIPPING] operation: " + Arrays.toString(step) + " is skipped due to 'skip' tag.");
				continue;
			}
			Thread.sleep(500);
			webdriver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
			action.perform(allObjects, step[Scenario.CELL_TS_ID], step[Scenario.CELL_KEYWORD], step[Scenario.CELL_OBJECT], step[Scenario.CELL_VALUE], step[Scenario.CELL_TAGS]);
			step[Scenario.CELL_STATE] = "PASS";
		}
				
	}


	//this after method will immediately run after a test. It will check the test result, and if it is fail, will get a screenshot of the web and store it in test-fail-screenshot folder
	@AfterMethod
	public void takeScreenShotOnFailure(ITestResult testResult) throws IOException { 
		if (testResult.getStatus() == ITestResult.FAILURE) {    		
			System.out.println("TS Failed. Status: "+testResult.getStatus()); 
			File scrFile = ((TakesScreenshot)webdriver).getScreenshotAs(OutputType.FILE); 
			FileUtils.copyFile(scrFile, new File(System.getProperty("user.dir")+ File.separator 
					+ "test-fail-screenshot"+ File.separator + testName + File.separator + Scenario.CELL_TS_ID +"_screenshot.jpg"));
			//webdriver.quit();
		} 
		if(testResult.getStatus() == ITestResult.SKIP){
			webdriver.quit();
		}
	}

	@DataProvider(name="scenario")
	public Object[][] getScenarioDataFromExcel() throws IOException {

		ReadExcelFile file = new ReadExcelFile();
		Sheet excelSheet = file.readExcel(System.getProperty("user.dir") + File.separator, "TestSuites.xlsx" , this.sheet);
		int rowCount = excelSheet.getLastRowNum()-excelSheet.getFirstRowNum();
		Scenario scenario = null;

		List<Scenario[]> provider = new ArrayList<Scenario[]>();
		List<String[]> steps = null;

		for (int i = 0; i < rowCount; i++) {
			//Loop over all the rows
			Row row = excelSheet.getRow(i+1);
			// Check first cell on every row, if first cell is not empty, start new scenario. if empty, continue add steps on current scenario.
			String firstCell = row.getCell(0).toString();
			if (firstCell != null && firstCell.length() > 0) {
				if (scenario == null) {
					scenario = new Scenario();
				} else {
					scenario.setSteps(steps);
					provider.add(new Scenario[] {scenario});
					scenario = new Scenario();
				}

				String[] scenarioDetail = new String[row.getLastCellNum()];
				steps = new ArrayList<String[]>();
				for (int j = 0; j < row.getLastCellNum(); j++) {
					scenarioDetail[j] = row.getCell(j).toString();
				}

				Log.d("add scenario detail: " + Arrays.toString(scenarioDetail));
				scenario.setScenarioDetail(scenarioDetail);

			} else {
				// add 1 index in last scenario detail for test state.
				String[] stepDefinition = new String[row.getLastCellNum() +1];
				for (int j = 0; j < row.getLastCellNum(); j++) {
					if (row.getCell(j).toString().length() < 1) {
						stepDefinition[j] = "";
					} else {
						stepDefinition[j] = row.getCell(j).toString();
					}
					
				}

				Log.d("add step: " + Arrays.toString(stepDefinition));
				steps.add(stepDefinition);
			}
			//Create a loop to print cell values in a row
			// last row
			if (i == rowCount-1) {
				scenario.setSteps(steps);
				provider.add(new Scenario[] {scenario});
			}
		}
		return provider.toArray(new Object[provider.size()][]);

	}

}
