package report;

import java.io.File;
import java.io.IOException;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.testng.IReporter;
import org.testng.IResultMap;
import org.testng.ISuite;
import org.testng.ISuiteResult;
import org.testng.ITestContext;
import org.testng.ITestResult;
import org.testng.xml.XmlSuite;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

import objects.Scenario;
import runTest.ExecuteTestCase;
import runTest.Utils.Tag;
 

public class ExtentReporterNG implements IReporter {
	 private ExtentReports extent;
	 
	    @Override
	    public void generateReport(List<XmlSuite> xmlSuites, List<ISuite> suites, String outputDirectory) {
	        extent = new ExtentReports(outputDirectory + File.separator + "Dexter-ExtentReport.html", true);
	        extent.config()
	        .reportName("Dexter")
	        .reportHeadline("Desktop Automation testing");
	        
//	        String mail = "";
	 
	        for (ISuite suite : suites) {
	            Map<String, ISuiteResult> result = suite.getResults();
//	            mail = suite.getParameter("mail");
	            for (ISuiteResult r : result.values()) {
	                ITestContext context = r.getTestContext();
	 
	                buildTestNodes(context.getPassedTests(), LogStatus.PASS);
	                buildTestNodes(context.getFailedTests(), LogStatus.FAIL);
	                buildTestNodes(context.getSkippedTests(), LogStatus.SKIP);
	            }
	        }
	 
	        extent.flush();
	        extent.close();

	    }
	 
	    private void buildTestNodes(IResultMap tests, LogStatus status) {
	        ExtentTest test;
	        
	        if (tests.size() > 0) {
	            for (ITestResult result : tests.getAllResults()) {
	            	Object[] parameters = result.getParameters();
	            	
	            	// get all parameters from test
	            	if (parameters !=null && parameters.length > 0) {
	            		Scenario scenario = (Scenario) parameters[0];
	            		ExtentTest parent = extent.startTest(result.getMethod().getMethodName() +  " Scenario: #" +
	    	                	scenario.getScenarioDetail()[Scenario.CELL_TESTCASENAME] +" [" + 
	    	                	scenario.getScenarioDetail()[Scenario.CELL_DESCRIPTIONS] + "]");
	    	            String message = "Test " + status.toString().toLowerCase() + "ed";
	    	            boolean failedFound = false;
	    	            boolean testSkipped = false;
	    	            
	    	            List<String[]> steps = scenario.getSteps();
	    	            if (scenario.getScenarioDetail()[Scenario.CELL_TAGS] != null 
	    	            		&& (scenario.getScenarioDetail()[Scenario.CELL_TAGS].contains(Tag.SKIP) 
	    	            				|| status == LogStatus.SKIP )) {
	                		testSkipped = true;
	                	}
	    	            
	    	            for (int i = 0; i < steps.size(); i++) {
							String[] step = steps.get(i);
							if (step == null) continue;
							
							String stepID = "[" + step[Scenario.CELL_TS_ID] +"]";
							
							StringBuilder sb = new StringBuilder();
							sb.append("Step Detail [");
							sb.append(step[Scenario.CELL_DESCRIPTIONS] + ": ");
	                		sb.append(step[Scenario.CELL_PAGE_NAME] + ", ");
	                		sb.append(step[Scenario.CELL_KEYWORD] + ", ");
	                		sb.append(step[Scenario.CELL_OBJECT] + ", ");
	                		sb.append(step[Scenario.CELL_VALUE] + ", ");
	                		sb.append(step[Scenario.CELL_TAGS] + "]. ");
	                		
	                		LogStatus stat = null;
	                		String stepState = step[Scenario.CELL_STATE];
	                		ExtentTest child = extent.startTest("Step #" + (i+1) + " " + step[Scenario.CELL_DESCRIPTIONS]);
	                		
	                		if (testSkipped) {
	                			stat = LogStatus.SKIP;
	                			sb.append("Step skipped due to the test being skipped.");
	                		} else if (stepState == null || stepState.isEmpty()) {
	                			if (failedFound) {
	                				stat = LogStatus.SKIP; 
	                				sb.append("Step skipped due to failing step in previous steps.");
	                			} else {
	                				failedFound = true;
	                				sb.append("Step failed. ");
	                				if (result.getThrowable() != null)
	                					sb.append(result.getThrowable().getMessage());
	                				
	                				stat = LogStatus.FAIL;
	                			}
	                		} else if (stepState.equalsIgnoreCase("PASS")) {
	                			stat = LogStatus.PASS; 
	                			sb.append("Step passed");
	                		} else if (stepState.equalsIgnoreCase("SKIP")) {
	                			stat = LogStatus.SKIP;
	                			sb.append("Step skipped");
	                		} else {
	                			stat = LogStatus.UNKNOWN; 
	                			sb.append("Unknown state: " + stepState);
	                		}
	                		
	                		if (step[Scenario.CELL_TAGS] != null && step[Scenario.CELL_TAGS].contains(Tag.CONTINUE_ON_FAIL) && !testSkipped) {
	                			sb.append(" [NOTE] Step containing tag: '" + Tag.CONTINUE_ON_FAIL + 
	                					"' please see TestNG reporter log for detail.");
	                		}
	                		
	                		child.log(stat, stepID, sb.toString());
	                		parent.appendChild(child);

						}
	    	            
	    	            parent.getTest().startedTime = getTime(result.getStartMillis());
	    	            parent.getTest().endedTime = getTime(result.getEndMillis());
	    	            
	    	            // set testcase group
	    	            for (String group : result.getMethod().getGroups()) {
	    	            	parent.assignCategory(group);
	    	            }
	    	            
	    	            if (result.getThrowable() != null ) {
	    	            	message = result.getThrowable().getMessage();
	    	            }
	    	            
	    	            parent.log(status, message);
	    	            extent.endTest(parent);
	            	}
	            	

	            }
	        }
	    }
	 
	    // method to get the time of testcase invoked
	    private Date getTime(long millis) {
	        Calendar calendar = Calendar.getInstance();
	        calendar.setTimeInMillis(millis);
	        return calendar.getTime();        
	    }

}
