This is Dexter for Desktop version.
For now it covering UI Automation for Firefox and Chrome


Thank You


Danny Aguswahyudi & Lauren Vicky Calista